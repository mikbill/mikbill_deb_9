// Информация о компании
var company_name = "MikBiLL";
var company_phones = "0-000-000-00-00, 000-00-00-0";
var company_phones_text = "Телефоны технической поддержки: ";

// Ссылки на ЛК
var lk_url = "https://stat.isp.demo/main.php";
var lk_url_unfreezee = "https://stat.isp.demo";

// Футер страницы
var year = (new Date).getFullYear() + " ";
var footer_text = ' Networks. All rights reserved.';

// Текст для должников
var nomoney_title = 'Недостаточно средств ';
var nomoney_text = 'На вашем счету недостаточно средств. <br/> Вы можете пополнить свой счет в <a href="' +  lk_url + '" rel="external"> Личном кабинете </a>';

// Текст для замороженых
var freezee_title = 'Активна услуга "заморозки" ';
var freezee_text = 'Ваша учетная запись "заморожена". <br/> Вы можете остановить услугу "заморозки" в <a href="' +  lk_url_unfreezee + '" rel="external"> Личном кабинете </a>';

// Текст для отключенных 
var disabled_title = 'Учетная запись отключена ';
var disabled_text = 'Ваша учетная запись отключена. ';

// Текст для удаленных
var deleted_title = 'Учетная запись удалена ';
var deleted_text = 'Ваша учетная запись удалена. ';

// Текст для неизвестных
var unknown_title = 'Неизвестный абонент ';
var unknown_text = 'Вы не зарегистрированы в нашей сети. Хотите стать нашим клиеном ? <br/> Позвоните нам или зарегистрируйтесь в <a href="' +  lk_url + '" rel="external"> Личном кабинете </a>';