#!/bin/bash

cd /var/www/devel/ad/res/smsukr
/usr/bin/php ./smsukr.php
