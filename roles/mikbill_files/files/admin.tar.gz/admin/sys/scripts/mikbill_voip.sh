#!/bin/bash

cd /var/www/mikbill/admin
#for BSD
#cd /usr/local/www/mikbill/admin

php ./index.php do_voip_calls

