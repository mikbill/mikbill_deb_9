#!/bin/bash

PHP=`which php`
cd /var/www/mikbill/admin/

$PHP ./index.php mbp_ram_graph $1
