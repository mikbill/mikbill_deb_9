#!/bin/bash

# writen by LD for MikBiLL
# http://www.mikbill.ru
#
# script params
# $1 - switch ip from MikBiLL Database
# $2 - switch port from MikBiLL Database
# $3 - switch snmp comunity from MikBiLL Database
# $4 - switch snmp port from MikBiLL Database
# $5 - switch login from MikBiLL Database
# $6 - switch pass from MikBiLL Database
# $7 - switchtype ID from MikBiLL Database
# $8 - serviceacl

echo `date` >> /var/www/mikbill/admin/sys/scripts/log.txt
echo "iptv_del"  >> /var/www/mikbill/admin/sys/scripts/log.txt
echo "$1 $2 $3 $4 $5 $6 $7 $8" >> /var/www/mikbill/admin/sys/scripts/log.txt