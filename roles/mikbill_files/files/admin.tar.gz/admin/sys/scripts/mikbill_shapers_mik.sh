#!/bin/bash

cd /var/www/mikbill/admin/res/shapers

php -q ./shapers.php
