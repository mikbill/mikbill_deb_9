SET NAMES 'utf8';

INSERT INTO system_options (`key`, value) VALUES ('required_who_and_where_issued' , '0');
INSERT INTO system_options (`key`, value) VALUES ('required_pasport_date_resive' , '0');
