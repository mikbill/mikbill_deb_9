SET NAMES 'utf8';

INSERT INTO bugh_plategi_type (bughtypeid, typename, sign, fictitious, deposit_action, deposit_action_by_user) VALUES (102, 'Пополнение Uniteller', '+', 0, '+', '+');

