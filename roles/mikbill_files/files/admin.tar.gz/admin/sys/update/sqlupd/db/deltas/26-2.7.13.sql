SET NAMES 'utf8';


INSERT INTO system_options (`key`, value) VALUES ('elecsnet_uid_prio', '1');
INSERT INTO system_options (`key`, value) VALUES ('elecsnet_login_prio', '2');
INSERT INTO system_options (`key`, value) VALUES ('elecsnet_numdogovor_prio', '3');
INSERT INTO system_options (`key`, value) VALUES ('elecsnet_uid', '1');
INSERT INTO system_options (`key`, value) VALUES ('elecsnet_login', '1');

INSERT INTO `radpostauthreplymessage` (
`replymessageid` ,
`replymessage`
)
VALUES (
NULL , 'Выкинуть.Accel Пополнение счета.'
);


