SET NAMES 'utf8';

ALTER TABLE radacctmem
  ADD INDEX uid (uid);

