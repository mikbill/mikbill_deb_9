SET NAMES 'utf8';

INSERT INTO system_options (`key`, value)
  VALUES ('address_template', '');

INSERT INTO system_options (`key`, value) 
VALUES ('generate_pwd_length' , '8'), ('generate_pwd_latin', 1), ('generate_pwd_numerical', '1');
