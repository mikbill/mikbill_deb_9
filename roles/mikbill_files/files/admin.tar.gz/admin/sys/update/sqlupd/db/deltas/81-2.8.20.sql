SET NAMES 'utf8';

ALTER TABLE `usersfreeze` ADD INDEX `uid` (`uid`);

