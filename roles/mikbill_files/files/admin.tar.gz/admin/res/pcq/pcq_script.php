<?php

define ("BILL_AUTH_TABLE","users");
define ("BILL_USERFREEZE_TABLE","usersfreeze");
define ("BILL_NAS_TABLE", "radnas" );
define ("BILL_PACKET_TABLE", "packets");
define ("BILL_PACKET_NAS_TABLE", "packetsnas");
define ("BILL_SYSTEM_OPTIONS_TABLE", "system_options");

$config_file='../../app/etc/config.xml';

if (file_exists($config_file)) {
	$xml = simplexml_load_file($config_file);
	$CONF_LOG  = (string) $xml->parameters->kernel->log;
	$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;

} else {
	die("config not found");
}

function open_logs($CONF_LOG)
{
	return 	fopen($CONF_LOG, "a");
}

$stdlog = open_logs($CONF_LOG);


function do_log($stdlog,$text_log)
{
	echo  get_date()." ".$text_log."\n";
}

function do_log_sql($stdlog,$text_log,&$LINK)
{
	echo  get_date()." ".$text_log."\n";
	return "1";
}


function get_date()
{
	return date ( 'd.m.Y H:i:s' );
}
	
	/*
 * Счетчик абонентов (Общее колличество абонентов)
 */
function billing_init_count($LINK, $stdlog) {
	$count = 0;
	
	$result = mysql_query ( "SELECT count(uid) as count  FROM " . BILL_AUTH_TABLE . " ", $LINK ) or do_log_sql ( $stdlog, "#1 " . mysql_error ( $LINK ) );
	$res = mysql_fetch_array ( $result );
	mysql_free_result ( $result );
	$count = $count + $res ['count'];
	
	$result = mysql_query ( "SELECT count(uid) as count  FROM " . BILL_USERFREEZE_TABLE . " ", $LINK ) or do_log_sql ( $stdlog, "#2 " . mysql_error ( $LINK ) );
	
	$res = mysql_fetch_array ( $result );
	mysql_free_result ( $result );
	$count = $count + $res ['count'];
	
	$res ['count'] = $count;
	return $res;
}

function init_nas($LINK,$stdlog)
{

	$result = mysql_query ( "SELECT * FROM " . BILL_NAS_TABLE . " WHERE shapertype=6 ", $LINK ) or do_log_sql($stdlog,"#2 ".mysql_error ( $LINK ),$LINK );

	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$nases[$res['id']]=$res;
	}

	mysql_free_result ( $result );

	return $nases;
}

function billing_init_system_options($LINK)
{
	$result = mysql_query ( "SELECT * FROM ".BILL_SYSTEM_OPTIONS_TABLE." WHERE 1 ", $LINK ) or die();
	$options= array();
	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$options[$res['key']]=$res['value'];
	}
	mysql_free_result($result);
	return $options;
}

function billing_init_packets($LINK,$stdlog)
{
	$packets = array();
	$result = mysql_query ( "SELECT * FROM " . BILL_PACKET_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$packets[$res["gid"]]=$res;
	}
	mysql_free_result($result);
	return $packets;
}

function billing_init_packets_by_nas($nasid,$LINK,$stdlog)
{
	$packets = array();
	$result = mysql_query ( "SELECT * FROM " . BILL_PACKET_TABLE . " WHERE gid in (SELECT gid FROM " . BILL_PACKET_NAS_TABLE . " WHERE nasid=".$nasid.")", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$packets[$res["gid"]]=$res;
	}
	mysql_free_result($result);
	return $packets;
}

function ftp_upload($ftp_server,$ftp_user_name,$ftp_user_pass,$file_in,$file_out)
#функция закачки на FTP
{
	$conn_id = ftp_connect($ftp_server);
	$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);

	if ((!$conn_id) || (!$login_result)) {
		echo "No connect with $ftp_server via $ftp_user_name!\n";
		//			exit;
	}
	$upload = ftp_put($conn_id, $file_out, $file_in, FTP_BINARY);
	
	if (!$upload) {
		echo "Error upload!";
	}
	ftp_close($conn_id);
}


global $LINK;

$LINK = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
if (!$LINK) {
	die("Cant connect to DB ".$CONF_MYSQL_HOST);
}

mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK ) or die('Could not select database.');
mysql_query("SET NAMES koi8r", $LINK ) or die('Could not NAMES database.');
mysql_query("SET CHARSET koi8r", $LINK ) or die('Could not CHARSET database.');


$system_options=billing_init_system_options($LINK);
$nas_list=init_nas($LINK,$stdlog);

$packets_list=billing_init_packets($LINK,$stdlog);

$comment="mikbill_auto";

foreach ($nas_list as $key=>$value)
{

	$file_content=array();

	# Удаление шейперов созданых скриптом MikBIll
	# /ip firewall mangle remove [find comment="mikbill_auto"]
	# /queue simple remove [find comment="mikbill_auto"]
	# /queue type remove [find name "mikbill."]
	
	array_push($file_content,"/ip firewall mangle remove [find comment~\"mikbill_auto\"]\n");
	array_push($file_content,"/queue simple remove [find comment~\"mikbill_auto\"]\n");
	array_push($file_content,"/queue tree remove [find comment~\"mikbill_auto\"]\n");
	array_push($file_content,"/queue type remove [find name~\"mikbill.\"]\n");

	$packets_list_by_nas=billing_init_packets_by_nas($key,$LINK,$stdlog);
	
	$get_users_count=billing_init_count($LINK,$stdlog);
	$max_users=$get_users_count["count"];
	$pcq_limit = 50;
	$pcq_total_limit = round((($max_users * $pcq_limit)/2),0);
	
	foreach ($packets_list_by_nas as $key2=>$value2)
	{
		$addr_list = $value2 ['mikrotik_addr_list'];
		$addr_list_in = $addr_list . '-OUT';
		$addr_list_out = $addr_list . '-IN';
		

		
	if (trim ( $addr_list ) != '')
	{
			array_push ( $file_content, "/ip firewall mangle\n" );
			array_push ( $file_content, "add action=mark-packet chain=prerouting comment=\"" . $comment . $addr_list_in . "\" disabled=no \\\n" );
			array_push ( $file_content, "    new-packet-mark=" . $addr_list_in . " passthrough=yes src-address-list=\\\n" );
			array_push ( $file_content, "    " . $addr_list . "\n" );
			array_push ( $file_content, "add action=mark-packet chain=postrouting comment=\"" . $comment . $addr_list_out ."\" disabled=no \\\n" );
			array_push ( $file_content, "    dst-address-list=" . $addr_list . " new-packet-mark=" . $addr_list_out . " passthrough=yes\n" );
			

			
			
	if ($value2 ['do_shapers_day_night'] == 0) {
				// шейпер по времени суток отключен
				// делаем обычный круглосуточный шейпер
				$speed_in = $value2 ['speed_rate'];
				$speed_out = $value2 ['speed_burst'];
				
				$queue_type_in = $comment . $addr_list_in;
				$queue_type_out = $comment . $addr_list_out;
				
				array_push ( $file_content, "/queue type\n" );
				array_push ( $file_content, "add kind=pcq name=" . $queue_type_out . " pcq-burst-rate=0 pcq-burst-threshold=0 \\\n" );
				array_push ( $file_content, "    pcq-burst-time=10s pcq-classifier=dst-address pcq-dst-address-mask=32 \\\n" );
				array_push ( $file_content, "    pcq-dst-address6-mask=64 pcq-limit=".$pcq_limit." pcq-rate=" . $speed_in . "k pcq-src-address-mask=32 \\\n" );
				array_push ( $file_content, "    pcq-src-address6-mask=64 pcq-total-limit=".$pcq_total_limit."\n" );
				
				array_push ( $file_content, "add kind=pcq name=" . $queue_type_in . " pcq-burst-rate=0 pcq-burst-threshold=0 \\\n" );
				array_push ( $file_content, "    pcq-burst-time=10s pcq-classifier=src-address pcq-dst-address-mask=32 \\\n" );
				array_push ( $file_content, "    pcq-dst-address6-mask=64 pcq-limit=".$pcq_limit." pcq-rate=" . $speed_out . "k pcq-src-address-mask=32 \\\n" );
				array_push ( $file_content, "    pcq-src-address6-mask=64 pcq-total-limit=".$pcq_total_limit."\n" );
				
				array_push ( $file_content, "/queue tree\n" );
				array_push ( $file_content, "add comment=" . $comment . "\\\n" );
				array_push ( $file_content, "   disabled=yes name=" . $addr_list_out . " packet-mark=" . $addr_list_out . "\\\n" );
				array_push ( $file_content, "	parent=global priority=1 queue=" . $queue_type_out . "\n" );
				array_push ( $file_content, "add comment=" . $comment . "\\\n" );
				array_push ( $file_content, "   disabled=yes name=" . $addr_list_in . " packet-mark=" . $addr_list_in . "\\\n" );
				array_push ( $file_content, "	parent=global priority=1 queue=" . $queue_type_in . "\n" );
			} else {
				
				// шейпер по времени суток включен
				// ниже код для первого временного интервала

				$speed_in = $value2 ['dop_interval1_speed_in'];
				$speed_out = $value2 ['dop_interval1_speed_out'];
				
				$queue_type_in = $comment . $addr_list_in."-interval1";
				$queue_type_out = $comment . $addr_list_out."-interval1";
				
				array_push ( $file_content, "/queue type\n" );
				array_push ( $file_content, "add kind=pcq name=" . $queue_type_out . " pcq-burst-rate=0 pcq-burst-threshold=0 \\\n" );
				array_push ( $file_content, "    pcq-burst-time=10s pcq-classifier=dst-address pcq-dst-address-mask=32 \\\n" );
				array_push ( $file_content, "    pcq-dst-address6-mask=64 pcq-limit=".$pcq_limit." pcq-rate=" . $speed_in . "k pcq-src-address-mask=32 \\\n" );
				array_push ( $file_content, "    pcq-src-address6-mask=64 pcq-total-limit=".$pcq_total_limit."\n" );
				
				array_push ( $file_content, "add kind=pcq name=" . $queue_type_in . " pcq-burst-rate=0 pcq-burst-threshold=0 \\\n" );
				array_push ( $file_content, "    pcq-burst-time=10s pcq-classifier=src-address pcq-dst-address-mask=32 \\\n" );
				array_push ( $file_content, "    pcq-dst-address6-mask=64 pcq-limit=".$pcq_limit." pcq-rate=" . $speed_out . "k pcq-src-address-mask=32 \\\n" );
				array_push ( $file_content, "    pcq-src-address6-mask=64 pcq-total-limit=".$pcq_total_limit."\n" );
				
				array_push ( $file_content, "/queue simple\n" );
				array_push ( $file_content, "add burst-limit=0/0 burst-threshold=0/0 burst-time=0s/0s comment=" . $comment ."-interval1\\\n" );
				array_push ( $file_content, "    disabled=no  limit-at=0/0 max-limit=0/0 name=\\\n" );
				array_push ( $file_content, "    " . $addr_list . "-interval1 packet-marks=" . $addr_list_out . "," . $addr_list_in . " parent=\\\n" );
				array_push ( $file_content, "    none  queue=" . $queue_type_in . "/" . $queue_type_out . " target=\"\" \\\n" );
				array_push ( $file_content, "    time=".$value2 ['dop_interval1_time1']."-".$value2 ['dop_interval1_time2'].",sun,mon,tue,wed,thu,fri,sat  total-queue=default-small\n" );
				
		if ($value2 ['dop_do_interval2'] == 1) {
					// временнйо интервал 2 включен
					// ниже код для 2го временного интервала
					$speed_in = $value2 ['dop_interval2_speed_in'];
					$speed_out = $value2 ['dop_interval2_speed_out'];
					
					$queue_type_in = $comment . $addr_list_in."-interval2";
					$queue_type_out = $comment . $addr_list_out."-interval2";
					
					array_push ( $file_content, "/queue type\n" );
					array_push ( $file_content, "add kind=pcq name=" . $queue_type_out . " pcq-burst-rate=0 pcq-burst-threshold=0 \\\n" );
					array_push ( $file_content, "    pcq-burst-time=10s pcq-classifier=dst-address pcq-dst-address-mask=32 \\\n" );
					array_push ( $file_content, "    pcq-dst-address6-mask=64 pcq-limit=".$pcq_limit." pcq-rate=" . $speed_in . "k pcq-src-address-mask=32 \\\n" );
					array_push ( $file_content, "    pcq-src-address6-mask=64 pcq-total-limit=".$pcq_total_limit."\n" );
					
					array_push ( $file_content, "add kind=pcq name=" . $queue_type_in . " pcq-burst-rate=0 pcq-burst-threshold=0 \\\n" );
					array_push ( $file_content, "    pcq-burst-time=10s pcq-classifier=src-address pcq-dst-address-mask=32 \\\n" );
					array_push ( $file_content, "    pcq-dst-address6-mask=64 pcq-limit=".$pcq_limit." pcq-rate=" . $speed_out . "k pcq-src-address-mask=32 \\\n" );
					array_push ( $file_content, "    pcq-src-address6-mask=64 pcq-total-limit=".$pcq_total_limit."\n" );
					
					array_push ( $file_content, "/queue simple\n" );
					array_push ( $file_content, "add burst-limit=0/0 burst-threshold=0/0 burst-time=0s/0s comment=" . $comment ."-interval2 \\\n" );
					array_push ( $file_content, "    disabled=no  limit-at=0/0 max-limit=0/0 name=\\\n" );
					array_push ( $file_content, "    " . $addr_list . "-interval2 packet-marks=" . $addr_list_out . "," . $addr_list_in . " parent=\\\n" );
					array_push ( $file_content, "    none  queue=" . $queue_type_in . "/" . $queue_type_out . " target=\"\" \\\n" );
					array_push ( $file_content, "    time=".$value2 ['dop_interval2_time1']."-".$value2 ['dop_interval2_time2'].",sun,mon,tue,wed,thu,fri,sat  total-queue=default-small\n" );
				}
				
				if ($value2 ['dop_do_interval3'] == 1) {
					// временнйо интервал 3 включен
					// ниже код для 3го временного интервала
					$speed_in = $value2 ['dop_interval3_speed_in'];
					$speed_out = $value2 ['dop_interval3_speed_out'];
					
					$queue_type_in = $comment . $addr_list_in."-interval3";
					$queue_type_out = $comment . $addr_list_out."-interval3";
					
					array_push ( $file_content, "/queue type\n" );
					array_push ( $file_content, "add kind=pcq name=" . $queue_type_out . " pcq-burst-rate=0 pcq-burst-threshold=0 \\\n" );
					array_push ( $file_content, "    pcq-burst-time=10s pcq-classifier=dst-address pcq-dst-address-mask=32 \\\n" );
					array_push ( $file_content, "    pcq-dst-address6-mask=64 pcq-limit=".$pcq_limit." pcq-rate=" . $speed_in . "k pcq-src-address-mask=32 \\\n" );
					array_push ( $file_content, "    pcq-src-address6-mask=64 pcq-total-limit=".$pcq_total_limit."\n" );
					
					array_push ( $file_content, "add kind=pcq name=" . $queue_type_in . " pcq-burst-rate=0 pcq-burst-threshold=0 \\\n" );
					array_push ( $file_content, "    pcq-burst-time=10s pcq-classifier=src-address pcq-dst-address-mask=32 \\\n" );
					array_push ( $file_content, "    pcq-dst-address6-mask=64 pcq-limit=".$pcq_limit." pcq-rate=" . $speed_out . "k pcq-src-address-mask=32 \\\n" );
					array_push ( $file_content, "    pcq-src-address6-mask=64 pcq-total-limit=".$pcq_total_limit."\n" );
					
					array_push ( $file_content, "/queue simple\n" );
					array_push ( $file_content, "add burst-limit=0/0 burst-threshold=0/0 burst-time=0s/0s comment=" . $comment ."-interval3 \\\n" );
					array_push ( $file_content, "    disabled=no  limit-at=0/0 max-limit=0/0 name=\\\n" );
					array_push ( $file_content, "    " . $addr_list . "-interval3 packet-marks=" . $addr_list_out . "," . $addr_list_in . " parent=\\\n" );
					array_push ( $file_content, "    none queue=" . $queue_type_in . "/" . $queue_type_out . " target=\"\" \\\n" );
					array_push ( $file_content, "    time=".$value2 ['dop_interval3_time1']."-".$value2 ['dop_interval3_time2'].",sun,mon,tue,wed,thu,fri,sat  total-queue=default-small\n" );
				}
			}
		}
	}

	$file_name="./pcq_mikrotik.rsc";

	if (!is_writable ($file_name)) {
		$fp = fopen ($file_name, "w+");
		fclose($fp);
	}
	file_put_contents($file_name,$file_content);

	$nas_ip=$value['nasname'];
	$nas_login=$value['naslogin'];
	$nas_pass=$value['naspass'];

	$file_in=$file_name;
	$file_out='pcq_mikrotik.rsc';
	$file_exec=$file_out;
	ftp_upload($nas_ip,$nas_login,$nas_pass,$file_in,$file_out);

	$command='import '.$file_exec;

	$ssh=$system_options['ssh_path'].' '.$nas_login.'@'.$nas_ip;
	$mik_ssh=$system_options['sudo'].' '.$ssh.' ';
	exec($mik_ssh."$command"." &>/dev/null 2>&1");
}

mysql_close($LINK);
