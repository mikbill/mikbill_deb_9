<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>MIKBILL | Profile info </title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>
<body>

    <div id="wrapper">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <a href="login.html">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>
           <?php //var_dump($result); ?>
        </nav>
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Просмотр профиля</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="javascript:history.back();">Главная</a>
                        </li>
                        <li>
                            <a">Профиль</a>
                        </li>
                        <li class="active">
                            <strong> <?php echo $result["profile"]["user"] ?> </strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
            </div>

        <div class="wrapper wrapper-content animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrapper wrapper-content animated fadeInUp">
                        <div class="ibox">
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="m-b-md">
                                            <h2> <?php echo $result["profile"]["fio"] ?> </h2>
                                        </div>
                                        <dl class="dl-horizontal">
                                            <dt>Логин:</dt> <dd> <strong><?php echo $result["profile"]["user"] ?></strong>  </dd>
                                            <dt>Состояние:</dt> <dd>
                                                <span class="label label-<?php echo $result["profile"]["label"] ?>"> <?php echo $result["profile"]["text"] ?></span>
                                            </dd>
                                        </dl>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-4">
                                        <dl class="dl-horizontal">
                                            <dt>Номер договора:</dt> <dd><?php
                                                echo ($result["profile"]["numdogovor"] ? $result["profile"]["numdogovor"] : "Не заключен" );
                                                echo ($result["profile"]["datedogovor"] != "" ?  " от " . $result["profile"]["datedogovor"] : "");
                                                ?></dd>
                                            <dt>Телефон:</dt> <dd><?php echo $result["profile"]["phone"] ?></dd>
                                            <dt>Адрес:</dt> <dd><?php
                                                echo $result["profile"]["lane"] . " " . $result["profile"]["house"];
                                                echo ($result["profile"]["app"] != "" ? ", кв " . $result["profile"]["app"] : "");
                                                ?></dd>
                                        </dl>
                                    </div>
                                    <div class="col-lg-5" id="cluster_info">
                                        <dl class="dl-horizontal" >
                                            <dt>IP адрес:</dt> <dd><?php echo ($result["profile"]["real_ip"] ? $result["profile"]["framed_ip"] : $result["profile"]["local_ip"]) ?></dd>
                                            <dt>МАК адрес:</dt> <dd><?php echo $result["profile"]["local_mac"] ?></dd>
                                            <dt>Использует роутер:</dt> <dd><?php echo ($result["profile"]["use_router"] ?  "Да" : "Нет") ?></dd>
                                            <dt>Был в сети:</dt> <dd><?php echo $result["profile"]["last_connection"] ?></dd>
                                        </dl>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <dl class="dl-horizontal">
                                            <dt>Серия и номер:</dt> <dd><?php echo $result["profile"]["passportserie"] ?></dd>
                                            <dt>Дата выдачи:</dt> <dd><?php echo $result["profile"]["passportdate"] ?></dd>
                                            <dt>Кем и где выдан:</dt> <dd><?php echo $result["profile"]["passportgdevidan"] ?></dd>
                                            <dt>Прописка:</dt> <dd><?php echo $result["profile"]["passportpropiska"] ?></dd>
                                            <dt>ИНН:</dt> <dd><?php echo $result["profile"]["inn"] ?></dd>
                                            <dt>Дата рождения:</dt> <dd><?php echo $result["profile"]["date_birth"] ?></dd>
                                        </dl>
                                    </div>
                                </div>
                                <div class="row m-t-sm">
                                    <div class="col-lg-12">
                                        <div class="panel blank-panel">
                                            <div class="panel-heading">
                                                <div class="panel-options">
                                                    <ul class="nav nav-tabs">
                                                        <li class="active"><a href="#tab-1" data-toggle="tab">История сессий</a></li>
                                                        <li class=""><a href="#tab-2" data-toggle="tab">История платежей</a></li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <div class="panel-body">

                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab-1">
                                                        <div class="feed-activity-list">
                                                            <div class="row">
                                                                <form id="session_filter" role="form" action="index.php" method="get">
                                                                    <input type="hidden" name="request" value="detail" form="session_filter">
                                                                    <input type="hidden" name="uid" value="<?php echo $_GET["uid"] ?>" form="session_filter">
                                                                    <div class="col-sm-4">
                                                                        <div class="form-group">
                                                                            <label class="control-label" for="filter">Поиск по таблице</label>
                                                                            <div class="input-group col-sm-12">
                                                                                <input type="text" class="form-control input-sm m-b-xs" id="filter" placeholder="любые данные">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-3">
                                                                        <div class="form-group">
                                                                            <label class="control-label" for="sstart">Дата начала сессии</label>
                                                                            <div class="input-group date">
                                                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                                                                <input id="sstart" name="start" type="text" class="form-control" value="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-3">
                                                                        <div class="form-group">
                                                                            <label class="control-label" for="sstop">Дата конца сессии</label>
                                                                            <div class="input-group date">
                                                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                                                                <input id="sstop" name="stop" type="text" class="form-control" value="">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-sm-1">
                                                                        <br/>
                                                                        <button type="submit" class="btn btn-primary block full-width m-b" form="session_filter">Фильтр</button>
                                                                    </div>
                                                                </form>
                                                            </div>

                                                            <table class="footable table table-stripped toggle-arrow-tiny" data-page-size="15" data-filter=#filter>
                                                                <thead>
                                                                <tr>
                                                                    <th data-hide="phone,tablet">Сессия</th>
                                                                    <th>Подключился</th>
                                                                    <th>Отключился</th>
                                                                    <th data-hide="phone,tablet">Время</th>
                                                                    <th data-hide="phone,tablet">Входящий</th>
                                                                    <th data-hide="phone,tablet">Исходящий</th>
                                                                    <th data-hide="phone,tablet">vlan</th>
                                                                    <th data-hide="phone">IP/MAC</th>
                                                                    <th data-hide="phone">Реальный IP</th>
                                                                </tr>
                                                                </thead>
                                                                <tbody>
                                                                <?php
                                                                foreach($result["sessions"] as $se)
                                                                {
                                                                    echo "
                                                                        <tr>
                                                                            <td><span class='label label-". ($se["acctstoptime"]!="" ? "primary" : "warning") ."'>". ($se["acctstoptime"]!="" ? "завершена" : "активна") ."</span></td>
                                                                            <td>{$se["acctstarttime"]}</td>
                                                                            <td>". ($se["acctstoptime"]!="0000-00-00 00:00:00" ? $se["acctstoptime"] : "") ."</td>
                                                                            <td>". sprintf('%02d:%02d:%02d', $se["acctsessiontime"]/3600, ($se["acctsessiontime"] % 3600)/60, ($se["acctsessiontime"] % 3600) % 60) ."</td>
                                                                            <td>" . round( ( $se["acctinputoctets"] / (1024*1024) ) , 3) . "</td>
                                                                            <td>" . round( ( $se["acctoutputoctets"] / (1024*1024) ) , 3) . "</td>
                                                                            <td>{$se["calledstationid"]}</td>
                                                                            <td>{$se["callingstationid"]}</td>
                                                                            <td>{$se["framedipaddress"]}</td>
                                                                        </tr>
                                                                    ";
                                                                }
                                                                ?>
                                                                </tbody>
                                                                <tfoot>
                                                                <tr>
                                                                    <td colspan="7">
                                                                        <ul class="pagination pull-right"></ul>
                                                                    </td>
                                                                </tr>
                                                                </tfoot>
                                                            </table>
                                                        </div>

                                                    </div>
                                                    <div class="tab-pane" id="tab-2">
                                                        <input type="text" class="form-control input-sm m-b-xs" id="filter2" placeholder="Поиск по таблице">

                                                        <table class="footable table table-stripped toggle-arrow-tiny" data-page-size="15" data-filter=#filter2>
                                                            <thead>
                                                            <tr>
                                                                <th>Дата</th>
                                                                <th data-hide="phone,tablet">До платежа</th>
                                                                <th>Сумма</th>
                                                                <th data-hide="phone">Тип платежа</th>
                                                                <th data-hide="phone">Примечание</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            <?php
                                                            foreach($result["pay"] as $pay)
                                                            {
                                                                echo "
                                                                        <tr>
                                                                            <td>{$pay["date"]}</td>
                                                                            <td>" . round( $pay["before_billing"] , 2) . "</td>
                                                                            <td>" . round( $pay["summa"] , 2) . "</td>
                                                                            <td><!--[{$pay["bughtypeid"]}]-->{$paytype[$pay["bughtypeid"]]}</td>
                                                                            <td>" . iconv('KOI8-U', 'UTF-8', $pay["comment"]) . "</td>
                                                                        </tr>
                                                                    ";
                                                            }
                                                            ?>
                                                            </tbody>
                                                            <tfoot>
                                                            <tr>
                                                                <td colspan="7">
                                                                    <ul class="pagination pull-right"></ul>
                                                                </td>
                                                            </tr>
                                                            </tfoot>
                                                        </table>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/plugins/pace/pace.min.js"></script>
    <!-- Data picker -->
    <script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>
    <!-- FooTable -->
    <script src="js/plugins/footable/footable.all.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {

            $('.footable').footable();

            $('#sstart').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

            $('#sstop').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

        });

    </script>
</body>
</html>