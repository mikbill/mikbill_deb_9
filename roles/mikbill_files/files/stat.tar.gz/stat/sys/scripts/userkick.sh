/bin/echo "Acct-Session-Id=5704682-vlan199-458,User-Name=admin2,NAS-IP-Address=10.10.254.7,Framed-IP-Address=195.2.205.185" | /usr/bin/radclient -r 1 10.10.254.7:3799 disconnect mik234
