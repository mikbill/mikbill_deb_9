<?php

function T_($msgid)
{

    global $nameLocale;

    $locale = array();

    $fileLocal = './data/locale/' . $nameLocale . '/' . $nameLocale . '.json';
    if (file_exists($fileLocal)) {
        $locale = json_decode(file_get_contents($fileLocal), true);
    }

    $fileCustomLocal = './data/locale/' . $nameLocale . '/custom.json';

    if (file_exists($fileCustomLocal)) {

        $localeCustom = json_decode(file_get_contents($fileCustomLocal), true);


        foreach ($localeCustom AS $key => $value) {
            $locale[$key] = $value;
        }
    }

    if (isset($locale[$msgid])) {
        return $locale[$msgid];
    } else {
        return $msgid;
    }
}

# Установка языка
function setLanguage($config)
{
    global $nameLocale;
    $locales = array();
    $lang_cookie = '';

    # Получаем локаль из куков
    if (isset($_COOKIE['lang'])) {
        $lang_cookie = $_COOKIE['lang'];
    }

    #Запись выбранного языка в куки
    if (isset($_GET['lang'])) {
        $lang_cookie = $_GET['lang'];
        SetCookie("lang", $lang_cookie, time() + (1000 * 24 * 60 * 60));
    }

    if (isset($config['config']['locales'])) {

        foreach ($config['config']['locales'] as $k => $v) {

            if (stristr($k, 'name_') !== false) {
                $key_name = str_replace('name_', '', $k);
                $val_en = 'enable_' . $key_name;
                $locales[$v] = array(
                    'enable' => $config['config']['locales'][$val_en]
                );
            }
        }
    }

    # Базовый язык ru-RU (на случай если по умолчанию язык недоступен или не включен)
    $defaultNameLocale = 'ru_RU';

    # Локализациия по умолчанию.
    if (isset($config['config']['locales_options']['default']) and $config['config']['locales_options']['default'] <> '') {
        $temp_default = $config['config']['locales_options']['default'];
        # Проверяем активированна ли локализация по умолчанию
        if (isset($locales[$temp_default])) {
            $defaultNameLocale = $temp_default;
        }
    }

    # Если включен автодетект
    if (isset($config['config']['locales_options']['autoDetect']) and $config['config']['locales_options']['autoDetect'] == 1) {

        $langDetect = new LangDetect();

        $langs = array(
            'ru_RU' => array('ru'),
            'uk_UA' => array('uk'),
            'en_GB' => array('en')
        );

        $detectNameLocale = $langDetect->getBestMatch($defaultNameLocale, $langs);

        # Проверяем активированна ли определенная локаль
        if (isset($locales[$detectNameLocale]) and $locales[$detectNameLocale]['enable'] == 1) {
            $nameLocale = $detectNameLocale;
        } else {
            $nameLocale = $defaultNameLocale;
        }
    } else {
        $nameLocale = $defaultNameLocale;
    }

    #Если язык из куков включен то используем его
    if (isset($locales[$lang_cookie]) and $locales[$lang_cookie]['enable'] == 1) {
        $nameLocale = $lang_cookie;
    }
}


class SystemsClass
{
    function get_input_data()
    {
        $params_input = array();

        if (!empty($_POST) AND is_array($_POST)) {
            foreach ($_POST as $k => $v) {
                $params_input[$k] = $v;
            }
        }

        if (!empty($_GET) AND is_array($_GET)) {
            foreach ($_GET as $k => $v) {
                $params_input[$k] = $v;
            }
        }

        return $params_input;
    }

    public function getBillLink($cabinetPath)
    {
        $result_array = array(
            'getserverdate'  => $cabinetPath . '/json/index/getserverdate',
            'authfl'         => $cabinetPath . '/ajax/index/authfl',
            'logoutfl'       => $cabinetPath . '/ajax/index/logoutfl',
            'gendogovorflex' => $cabinetPath . '/ajax/users/gendogovorflex',
            'geninvoice'     => $cabinetPath . '/ajax/users/geninvoice',
            'usevaucherfl'   => $cabinetPath . '/ajax/users/usevaucherfl',

            'getticketslist2x'               => $cabinetPath . '/ajax/ticketview/getticketslist2x',
            'getmessages'                    => $cabinetPath . '/ajax/ticketview/getmessages',
            'addticket'                      => $cabinetPath . '/ajax/ticketedit/addticket',
            'updateticket'                   => $cabinetPath . '/ajax/ticketedit/updateticket',
            'addmessage'                     => $cabinetPath . '/ajax/ticketedit/addmessage',
            'statpaymfl'                     => $cabinetPath . '/ajax/users/statpaymfl',
            'getcabinetnews'                 => $cabinetPath . '/ajax/users/getcabinetnewsdb',
            'stattrafflex'                   => $cabinetPath . '/ajax/users/stattrafflex',
            'tarifchangelistflex'            => $cabinetPath . '/ajax/users/tarifchangelistflex',
            'howmatchpayperehodflex'         => $cabinetPath . '/ajax/users/howmatchpayperehodflex',
            'dochangerealipflex'             => $cabinetPath . '/ajax/users/dochangerealipflex',
            'dochangetarifflex'              => $cabinetPath . '/ajax/users/dochangetarifflex',
            'getturboflex'                   => $cabinetPath . '/ajax/users/getturboflex',
            'getcreditflex'                  => $cabinetPath . '/ajax/users/getcreditflex',
            'getcreditprocentflex'           => $cabinetPath . '/ajax/users/getcreditprocentflex',
            'dochangedataflex'               => $cabinetPath . '/ajax/users/dochangedataflex',
            'dochangepassflex'               => $cabinetPath . '/ajax/users/dochangepassflex',
            'getuserdatafl'                  => $cabinetPath . '/ajax/users/getuserdatafl',
            'dofreezeuserfl'                 => $cabinetPath . '/ajax/users/dofreezeuserfl',
            'dounfreezeuserfl'               => $cabinetPath . '/ajax/users/dounfreezeuserfl',
            'doperevodfl'                    => $cabinetPath . '/ajax/users/doperevodfl',
            'dochangedatebirthflex'          => $cabinetPath . '/ajax/users/dochangedatebirthflex',
            'config_xml'                     => $cabinetPath . '/res/config.xml',
            'getconfightml'                  => $cabinetPath . '/ajax/index/getconfightml',
            'getcopaycourl'                  => $cabinetPath . '/ajax/users/getcopaycourl',
            'authip'                         => $cabinetPath . '/ajax/index/authip',
            'getotphtml'                     => $cabinetPath . '/ajax/index/getotphtml',
            'applyotphtml'                   => $cabinetPath . '/ajax/index/applyotphtml',
            'getpacketslistregistrationhtml' => $cabinetPath . '/ajax/index/getpacketslistregistrationhtml',
            'registrationType2'              => $cabinetPath . '/ajax/index/registrationType2',
            'restorepasswordsms'             => $cabinetPath . '/ajax/index/restorepasswordsms',
            'checkloggedin'                  => $cabinetPath . '/ajax/users/checkloggedin',
            'megogoserviceuserinfo'          => $cabinetPath . '/json/users/megogoserviceuserinfo',
            'megogoserviceuserpass'          => $cabinetPath . '/json/users/megogoserviceuserpass',
            'omegatvcode'                    => $cabinetPath . '/json/users/omegatvcode',
            'omegatvdevice'                  => $cabinetPath . '/json/users/omegatvdevice',
            'omegatvdevicedel'               => $cabinetPath . '/json/users/omegatvdevicedel',
            'omegatvcustomer'                => $cabinetPath . '/json/users/omegatvcustomer',

            'getuserdevices'   => $cabinetPath . '/json/users/getuserdevices',
            'deleteuserdev'    => $cabinetPath . '/json/users/deleteuserdev',
            'adduserdev'       => $cabinetPath . '/json/users/adduserdev',
            'adduserdevbycode' => $cabinetPath . '/json/users/adduserdevbycode',
            'getdevtypeslist'  => $cabinetPath . '/json/users/getdevtypeslist',

            'getactiveservicesuser'              => $cabinetPath . '/json/users/getactiveservicesuser',
            'getpersonalservicesuser'            => $cabinetPath . '/json/users/getpersonalservicesuser',
            'getallpersonalservicesuser'         => $cabinetPath . '/json/users/getallpersonalservicesuser',
            'setpersonalserviceuser'             => $cabinetPath . '/ajax/users/setpersonalserviceuser',
            'unsetpersonalserviceuser'           => $cabinetPath . '/ajax/users/unsetpersonalserviceuser',
            'getreplacelistpersonalservicesuser' => $cabinetPath . '/json/users/getreplacelistpersonalservicesuser',
            'checkchangemac'                     => $cabinetPath . '/ajax/users/checkchangemac'
        );

        return $result_array;
    }
}