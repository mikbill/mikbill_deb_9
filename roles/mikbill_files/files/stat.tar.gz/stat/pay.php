<?php
header('Content-type: text/html; charset=UTF-8');
/**
 * @author NickCool
 * @about  файл для уменьшения количества файлов платёжных систем в корне папки
 */

# сокращаем DS
define('DS', DIRECTORY_SEPARATOR);
define('BILL_SYSTEM_OPTIONS_TABLE', 'system_options');

# путь к платёжным системам
$pathToPS = '.' . DS . 'res' . DS . 'paysystems' . DS;
# вспомогательные ф-ии
include_once($pathToPS . 'helper' . DS . 'safemysql.class.php');
include_once($pathToPS . 'helper' . DS . 'functions.php');
include_once($pathToPS . 'helper' . DS . 'form.class.php');
include_once($pathToPS . 'helper' . DS . 'pay_api.php');


# файл-конфиг соединения с БД
$configFilePath = './app/etc/config.xml';

# соединение с БД
$LINK = connectToDB($configFilePath);

# необходимо задать в обработчиках ПС
$title = 'ISP - пополнение счёта';
$response = 'Error! Платёжная система не выбрана!';

#Check Payment Search API
if (getPostParam('data_api', false)) {
    $systemOptions = billingInitSystemOptionsByKey($LINK, 'payment_api_%');
    $apiClass = new PayApiClass($systemOptions, $LINK);
}


# NEW!!! инициализируем класс формы.
$form = new formClass();

# получаем необходимые данные для оплаты
# данные абонента
$user = getUserDataFromPOST();
# сумма платежа
$amount = round(getPostParam('amount', 100), 2);

/*
# для отладки
$amount = 10;
$amount = round($amount, 2);
$user['uid'] = 1;
$user['email'] = 'simple@e.mail';
*/

if (isset($_GET['system']) AND !empty($_GET['system'])) {
    $file = 'default.php';
    $systemName = $_GET['system'];
    # получаем сис. опции и проверяем, включены ли системы

    switch ($systemName) {
        # https://stripe.com - Stripe
        case 'stripe':
            # для Stripe нужны все сис. опции
            $systemOptions = billingInitSystemOptions($LINK);

            # заменяем символ из сис. опций на символ Евро
            $systemOptions['stripe_currency_symbol'] = '€';

            if (isset($systemOptions['stripe_on'], $systemOptions['stripe_secret_key'], $systemOptions['stripe_publishable_key'], $systemOptions['stripe_currency']) AND $systemOptions['stripe_on'] == 1) {
                # действие по умолчанию
                $file = 'form.php';

                if (isset($_GET['act'])) {
                    switch ($_GET['act']) {
                        # оплата
                        case 'pay':
                            if (isset($_POST['stripeToken'])) {
                                $file = 'charge.php';
                            }
                            break;
                    }
                }
            }
            break;

        case 'paykeeper':
            $systemOptions = billingInitSystemOptionsByKey($LINK, 'paykeeper_%');

            if (isset($systemOptions['paykeeper_on']) && $systemOptions['paykeeper_on'] == 1 && !empty($systemOptions['paykeeper_urlpay'])) {
                $file = 'index.php';
            }
            break;

        case 'ukrpays':
            $systemOptions = billingInitSystemOptionsByKey($LINK, 'ukrpays_%');

            if (isset($systemOptions['ukrpays_on']) && $systemOptions['ukrpays_on'] == 1 && isset($systemOptions['ukrpays_service_id']) && !empty($systemOptions['ukrpays_urlpay'])) {
                $file = 'index.php';
            }
            break;

        case 'paypal':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');

            if (isset($systemOptions['paypal_on'], $systemOptions['paypal_merchant'], $systemOptions['paypal_currency']) AND $systemOptions['paypal_on'] == 1 AND trim($systemOptions['paypal_merchant']) != '' AND trim($systemOptions['paypal_currency']) != '') {
                $file = 'index.php';
            }
            break;

        case 'uniteller':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'fondy':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'yandex':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'portmone':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'ipay':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'robokassa':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'simplepay':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'sberbankrumrch':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'liqpay':
            $systemOptions = billingInitSystemOptions($LINK);
            if (isset($systemOptions['do_liqpay_terminal'])) {
                $file = 'index.php';
            }
            break;

        case 'onpay':
            $systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '%');
            if (isset($systemOptions['do_onpay_terminal'])) {
                $file = 'index.php';
            }
            break;

        case 'privat24':
            $systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '%');
            if (isset($systemOptions['do_privat24_terminal'])) {
                $file = 'index.php';
            }
            break;

        case 'pscb':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'paymaster':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'yandexmoney':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'cloudpayments':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'isbank':
            $systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'wqiwiru':
            $systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '_%');
            if (isset($systemOptions['do_wqiwiru_terminal'])) {
                $file = 'index.php';
            }
            break;

        case 'tinkoff':
            $systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'alfabankru':
            $systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'privat_v2':
            $systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '%');

            if (isset($systemOptions['do_privat_v2'], $systemOptions['privat_v2_lk']) AND $systemOptions['do_privat_v2'] == '1' AND $systemOptions['privat_v2_lk'] == '1') {
                $file = 'index.php';
            }
            break;

        case 'paysoft':
            $systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;

        case 'ckassa':
            $systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '_%');
            if (isset($systemOptions[$systemName . '_on'])) {
                $file = 'index.php';
            }
            break;
    }

    # выполняем указанный файл
    if ($file == 'default.php') {
        include_once($pathToPS . $file);
    } else {
        include_once($pathToPS . $systemName . DS . $file);
    }

}

//Старые ПС
$oldPS = array(
    'stripe',
    'paykeeper',
    'paypal'
);


# выводим отформатированный ответ
if (in_array($systemName, $oldPS)) {

    # Старая форма
    echo setResponse($response, $title);
} else {

    # Новый класс формы
    echo $form->getForm();
}
