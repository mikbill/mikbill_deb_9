<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */

/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

// ProviderCode
if (isset($systemOptions[$systemName . '_provider_code'])) {
    $providerCode = $systemOptions[$systemName . '_provider_code'];
} else {
    $providerCode = "";
}

$user = getUser($LINK, $user['uid']);

if ($amount < 20) {
    $amount = 20;
}

$amount = $amount * 100;

$prio_search = get_search_queue_for_payment_system($systemOptions);

switch ($prio_search) {
    case 'uid':
    case 'login':

    case 'numdogovor':
    default:
        $action_url = "https://ckassa.ru/payment/?lite-version=true#!search_provider/pt_search/" . $providerCode . "/pay&amount=" . $amount . "&НОМЕР_ДОГОВОРА=" . $user['numdogovor'];
        break;
}


function get_search_queue_for_payment_system($systemOptions)
{
    $queue = array();

    // Поиск по UIDу
    if (isset($systemOptions['ckassa_uid_prio']) AND (int)$systemOptions['ckassa_uid_prio'] != 0) {
        if (!isset($queue[(int)$systemOptions['ckassa_uid_prio']])) {
            $queue[(int)$systemOptions['ckassa_uid_prio']] = 'uid';
        } else {
            $queue[] = 'uid';
        }
    }

    // Поиск по user (login)
    if (isset($systemOptions['ckassa_login_prio']) AND (int)$systemOptions['ckassa_login_prio'] != 0) {
        if (!isset($queue[(int)$systemOptions['ckassa_login_prio']])) {
            $queue[(int)$systemOptions['ckassa_login_prio']] = 'login';
        } else {
            $queue[] = 'login';
        }
    }

    // Поиск по номеру договора
    if (isset($systemOptions['ckassa_dogovor_prio']) AND (int)$systemOptions['ckassa_dogovor_prio'] != 0) {
        if (!isset($queue[(int)$systemOptions['ckassa_dogovor_prio']])) {
            $queue[(int)$systemOptions['ckassa_dogovor_prio']] = 'numdogovor';
        } else {
            $queue[] = 'numdogovor';
        }
    }

    if (empty($queue)) {
        $queue[] = 'default';
    }

    return array_shift($queue);
}

//var_dump($user);
//var_dump($action_url);
//die();

header('Location: ' . $action_url);

