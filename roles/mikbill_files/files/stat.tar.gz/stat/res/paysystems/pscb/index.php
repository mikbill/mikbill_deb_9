<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */


/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_pscb', 'order_date');

$merchant_key = $systemOptions[$systemName . '_MrchKey'];
$market_place_id = $systemOptions[$systemName . '_marketPlace'];
$test_mode = $systemOptions[$systemName . '_test'];

if ($test_mode == 0) {
	// Рабочий URL
	$action_url = "https://oos.pscb.ru/pay/";
} else {
	// Тестовый URL
	$action_url = "https://oosdemo.pscb.ru/pay/";
}

$message = array(
	"details" => "Оплата интернета" ,
	"amount" => $amount,
	"customerRating" => "5",
	"customerAccount" => $user['uid'],
	"orderId" => $order_id
);

$messageText = json_encode($message);
$http_params = array(
	"marketPlace" => $market_place_id,
	"message" => base64_encode($messageText),
	"signature" => hash('sha256', $messageText . $merchant_key)
);

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('PSCB');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('POST');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('marketPlace', $http_params['marketPlace']));
$form->addFieldForm($form->_input('message', $http_params['message']));
$form->addFieldForm($form->_input('signature', $http_params['signature']));

$form->addFieldForm($form->_group($form->_inputLabel(false,$user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$amount.' руб.', 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));
