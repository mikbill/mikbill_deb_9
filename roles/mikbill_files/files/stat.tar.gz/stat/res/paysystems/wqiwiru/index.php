<?php
/*
 *  wqiwiru Dashboard
 */

$orderid = startTransaction($LINK, $user, $amount, 'addons_wqiwiru', 'time_stamp', 'sum');

if (!empty($systemOptions[$systemName . '_shop_id'])) {
    $shop_ID = $systemOptions[$systemName . '_shop_id'];
} else {
    $shop_ID = '';
}

if (!empty($systemOptions[$systemName . '_rest_api_id'])) {
    $rest_ID = $systemOptions[$systemName . '_rest_api_id'];
} else {
    $rest_ID = '';
}

if (!empty($systemOptions[$systemName . '_rest_api_pwd'])) {
    $rest_PWD = $systemOptions[$systemName . '_rest_api_pwd'];
} else {
    $rest_PWD = '';
}

if (!empty($systemOptions[$systemName . '_stat_url'])) {
    $stat_URL = $systemOptions[$systemName . '_stat_url'];
} else {
    $stat_URL = '';
}

if (!empty($user['phone'])) {
    $phone = $user['phone'];

    if(!empty($_POST['wqiwiru_prompt'])){
        $phone = $_POST['wqiwiru_prompt']. $phone;
    }
} else {
    $phone = '';
}


# Название ПС
$form->setLabelForm('WalletQiwi.ru');

# POST form
$form->setMethodForm('GET');


#По старой схеме SOAP
if (!(isset($systemOptions[$systemName . '_rest_on']) and $systemOptions[$systemName . '_rest_on'] == 1)) {

    $actionUrl = 'http://w.qiwi.ru/setInetBill_utf.do';

    # Заполняем action URL для формы
    $form->setUrlForm($actionUrl);

    # заполняем форму полями
    $form->addFieldForm($form->_h('Информация по платежу:'));
    $form->addFieldForm($form->_hr());

    $form->addFieldForm($form->_input('from', $shop_ID));
    $form->addFieldForm($form->_input('to', $phone));
    $form->addFieldForm($form->_input('summ', $amount));
    $form->addFieldForm($form->_input('txn_id', $orderid));
    $form->addFieldForm($form->_input('com', 'uid=' . $user['uid']));

    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['phone'], 'Телефон:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' руб.', 'Cумма:')));
    $form->addFieldForm($form->_hr());
    $form->addFieldForm($form->_group($form->_button()));

} else {

    require(dirname(__FILE__) . '/lib/QIWI_REST.php');

    $COMMENT =  'uid=' . $user['uid'];
    $LIFETIME = date('Y-m-d\TH:i:s', time() + 6000);

    $qiwiClass = new QIWI_REST($shop_ID, $rest_ID, $rest_PWD);
    $qiwiClass->set_transaction($amount, $phone,  'RUB' , $LIFETIME, $COMMENT);
    $res = $qiwiClass->create_payment($orderid);

    if ($qiwiClass->_RESULT_CODE == 0){

        $actionUrl = 'https://qiwi.com/order/external/main.action';

        # Заполняем action URL для формы
        $form->setUrlForm($actionUrl);

        # заполняем форму полями
        $form->addFieldForm($form->_h('Информация по платежу:'));
        $form->addFieldForm($form->_hr());

        $form->addFieldForm($form->_input('shop', $shop_ID));
        $form->addFieldForm($form->_input('transaction', $orderid));
        $form->addFieldForm($form->_input('qiwi_phone', $phone));

        $form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
        $form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
        $form->addFieldForm($form->_group($form->_inputLabel(false, $user['phone'], 'Телефон:')));
        $form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' руб.', 'Cумма:')));
        $form->addFieldForm($form->_hr());
        $form->addFieldForm($form->_group($form->_button()));

    }else{
        # заполняем форму полями
        $form->addFieldForm($form->_h('Ошибка. ' . $qiwiClass->_DESC));
        $form->addFieldForm($form->_hr());
    }

}



