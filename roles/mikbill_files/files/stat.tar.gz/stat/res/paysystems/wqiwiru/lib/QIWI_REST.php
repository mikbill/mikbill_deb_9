<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 16.05.2017
 * Time: 17:12
 */
class QIWI_REST
{
    private $_URL_REDIRECT = false;

    private $_SHOP_ID;
    private $_REST_ID;
    private $_REST_PWD;

    private $_URL_GOOD;
    private $_URL_BAD;

    public $_RESULT_CODE;
    public $_DESC;


    private $_DATA_TRN = array();

    function __construct($SHOP_ID, $REST_ID, $REST_PWD)
    {
        $this->_SHOP_ID = $SHOP_ID;
        $this->_REST_ID = $REST_ID;
        $this->_REST_PWD = $REST_PWD;
    }

    public function set_urls($GOOD, $BAD)
    {
        $this->_URL_GOOD = $GOOD;
        $this->_URL_BAD = $BAD;
    }

    public function set_transaction($AMOUNT = '1.0', $PHONE,  $CCY = 'RUB', $LIFETIME, $COMMENT)
    {
        $this->_DATA_TRN['amount'] = $AMOUNT;
        $this->_DATA_TRN['user'] = "tel:+" . $PHONE;
        $this->_DATA_TRN['ccy'] = $CCY;
        $this->_DATA_TRN['lifetime'] = $LIFETIME;
        $this->_DATA_TRN['comment'] = $COMMENT;
    }

    public function create_payment($BILL_ID)
    {
        $result = $this->curl_request($this->_DATA_TRN, $BILL_ID);

        $json = json_decode($result);

        if (isset($json->response->result_code)){
            $this->_RESULT_CODE = $json->response->result_code;
        }

        if(isset($json->response->description)){
            $this->_DESC = $json->response->description;
        }

        return $result;
    }

    private function curl_request($DATA, $BILL_ID)
    {
        $ch = curl_init('https://api.qiwi.com/api/v2/prv/' . $this->_SHOP_ID . '/bills/' . $BILL_ID);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($DATA));
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, $this->_REST_ID . ":" . $this->_REST_PWD);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            "Accept: application/json"
        ));

        $result = curl_exec($ch);
        curl_close($ch);

        return $result;
    }
}