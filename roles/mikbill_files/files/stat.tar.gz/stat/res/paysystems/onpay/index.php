<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */


/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_onpay', 'paymentDateTime', 'order_amount');

$login = $systemOptions[$systemName . '_login'];
$secret = $systemOptions[$systemName . '_secret'];

$curency = $systemOptions[$systemName . '_ccy'];
$url_result = $systemOptions[$systemName . '_url_success'];

if (!empty($systemOptions[$systemName . '_commission_by_provider']) AND $systemOptions[$systemName . '_commission_by_provider'] == 1){
    $price_final =  'true';;
}else{
    $price_final = 'false';
}

$md5check = md5("fix;".to_float($amount).";".$curency.";".$order_id.";yes;".$secret);

$action_url = "http://secure.onpay.ru/pay/".$login;

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('OnPay');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('GET');


# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('pay_mode', 'fix'));
$form->addFieldForm($form->_input('price', $amount));

$form->addFieldForm($form->_input('currency', $curency));
$form->addFieldForm($form->_input('pay_for', $order_id));

$form->addFieldForm($form->_input('convert', 'yes'));
$form->addFieldForm($form->_input('price_final', $price_final));
$form->addFieldForm($form->_input('md5', $md5check));
$form->addFieldForm($form->_input('url_success', $url_result));

$form->addFieldForm($form->_group($form->_inputLabel(false,$user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$amount.' '.$curency, 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));
