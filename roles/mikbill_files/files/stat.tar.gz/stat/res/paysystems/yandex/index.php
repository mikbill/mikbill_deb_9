<?php
/**
 * Created by PhpStorm.
 * User: max_stupakov@mail.ru
 * Date: 02.11.2015
 * Time: 9:19
 */

if (empty($systemOptions['yandex_shopId'])) {
	die('Не указана системная опция yandex_shopId');
}

if (empty($systemOptions['yandex_scid'])) {
	die('Не указана системная опция yandex_scid');
}

//#Минимальный платеж для Yandex.Money
//if($amount < 100 ){
//	$amount = 100;
//}

$order_id = startTransaction($LINK, $user, $amount, 'addons_yandex');
$shopId = $systemOptions['yandex_shopId'];
$scid = $systemOptions['yandex_scid'];
$shopArticleId = $systemOptions['yandex_shopArticleId'];


if(!(empty($systemOptions['yandex_test']) and $systemOptions['yandex_test'] == 0)) {
	$actionUrl = 'https://demomoney.yandex.ru/eshop.xml';
}else{
	$actionUrl = 'https://money.yandex.ru/eshop.xml';
}

$paymentType = array(
	"AC" => "С банковской карты",
	"PC" => "Со счета в Яндекс.Деньгах"
);

# Название ПС
$form->setLabelForm('Яндекс.Касса');

# Заполняем action URL для формы
$form->setUrlForm($actionUrl);

# POST form
$form->setMethodForm('POST');

$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('fio', $user['fio']));
$form->addFieldForm($form->_input('shopId', $shopId));
$form->addFieldForm($form->_input('scid', $scid));
$form->addFieldForm($form->_input('customerNumber', $user['uid']));
$form->addFieldForm($form->_input('orderNumber', $order_id));
$form->addFieldForm($form->_input('cps_phone', $user['phone']));
$form->addFieldForm($form->_input('cps_email', $user['email']));
$form->addFieldForm($form->_input('sum', $amount));
$form->addFieldForm($form->_input('paymentType', ''));

$form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $amount, 'Cумма:')));
#$form->addFieldForm($form->_group($form->_selectLabel('paymentType', $paymentType, 'Тип оплаты:', false)));

$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));



