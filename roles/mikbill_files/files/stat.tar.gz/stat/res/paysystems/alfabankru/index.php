<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 08.08.2017
 * Time: 9:19
 */

/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_alfabankru');

$description = 'Internet UID ' . $user['uid'];

if (!empty($systemOptions[$systemName . '_api_username'])) {
    $api_username = $systemOptions[$systemName . '_api_username'];
} else {
    $api_username = "";
}

if (!empty($systemOptions[$systemName . '_api_password'])) {
    $api_password = $systemOptions[$systemName . '_api_password'];
} else {
    $api_password = "";
}

if (!empty($systemOptions[$systemName . '_return_url'])) {
    $return_url = $systemOptions[$systemName . '_return_url'];
} else {
    $return_url = "";
}

if (!empty($systemOptions[$systemName . '_test'])  AND $systemOptions[$systemName . '_test'] == 1) {
    $api_host = 'https://web.rbsuat.com/ab/rest/';
} else {
    $api_host = 'https://pay.alfabank.ru/payment/rest/';
}

require(dirname(__FILE__) . '/lib/AlfaBankRuAPI.php');

$api = new AlfaBankRuAPI($api_username, $api_password, $api_host);

$data = array(
    'returnUrl'   => $return_url,
    'orderNumber' => urlencode($order_id),
    'amount'      => $amount * 100,
    'description' => $description,
    'clientId'    => $user['uid']
);

// Создаем платеж
$response = $api->register_do($data);

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('Альфа-Банк');

# GET form
$form->setMethodForm('GET');

if (isset($response['errorCode'])) { // В случае ошибки вывести ее
    # заполняем форму полями
    $form->addFieldForm($form->_h('Ошибка #' . $response['errorCode'] . ': ' . $response['errorMessage']));
    $form->addFieldForm($form->_hr());
} else {

    // Обновим TXN_ID по платежу
    updateOrderID($LINK, $order_id, 'txn_id', $response['orderId'], 'addons_alfabankru');

    # Заполняем action URL для формы
    $form->setUrlForm($response['formUrl']);

    # заполняем форму полями
    $form->addFieldForm($form->_h('Информация по платежу:'));
    $form->addFieldForm($form->_hr());

    $form->addFieldForm($form->_input('mdOrder', $response['orderId']));

    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' руб.', 'Cумма:')));
    $form->addFieldForm($form->_hr());
    $form->addFieldForm($form->_group($form->_button()));
}
