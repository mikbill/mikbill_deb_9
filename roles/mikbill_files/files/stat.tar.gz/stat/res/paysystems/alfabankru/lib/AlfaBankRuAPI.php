<?php

class AlfaBankRuAPI
{
    private $_api_url;
    private $_api_UserName;
    private $_api_Password;

    /**
     * AlfaBankRuAPI constructor.
     *
     * @param $api_username
     * @param $api_password
     * @param string $api_url
     */
    public function __construct($api_username, $api_password, $api_url = 'https://web.rbsuat.com/ab/rest/')
    {
        $this->_api_url = $api_url;
        $this->_api_UserName = $api_username;
        $this->_api_Password = $api_password;
    }

    /**
     * Запрос регистрации заказа
     *
     * @param $args
     * @return mixed
     */
    public function register_do($args)
    {
        return $this->buildQuery('register.do', $args);
    }

    /**
     * Запрос состояния заказа
     *
     * @param $args
     * @return mixed
     */
    public function getOrderStatus_do($args)
    {
        return $this->buildQuery('getOrderStatus.do', $args);
    }


    /**
     * Builds a query string and call sendRequest method.
     * Could be used to custom API call method.
     *
     * @param string $path API method name
     * @param mixed $args query params
     *
     * @return mixed
     * @throws HttpException
     */
    public function buildQuery($path, $args)
    {
        if (is_array($args)) {
            if (!array_key_exists('userName', $args)) {
                $args['userName'] = $this->_api_UserName;
            }
            if (!array_key_exists('password', $args)) {
                $args['password'] = $this->_api_Password;
            }
        }

        $url = $this->_api_url . $path;

        return $this->_sendRequest($url, $args);
    }


    /**
     * Main method. Call API with params
     *
     * @param string $api_url API Url
     * @param array $args API params
     *
     * @return mixed
     * @throws HttpException
     */
    private function _sendRequest($api_url, $data)
    {
        $curl = curl_init(); // Инициализируем запрос
        curl_setopt_array($curl, array(
            CURLOPT_URL => $api_url, // Полный адрес метода
            CURLOPT_RETURNTRANSFER => true, // Возвращать ответ
            CURLOPT_POST => true, // Метод POST
            CURLOPT_POSTFIELDS => http_build_query($data), // Данные в запросе
            CURLOPT_SSL_VERIFYPEER => false
        ));
        $response = curl_exec($curl); // Выполненяем запрос

        $response = json_decode($response, true); // Декодируем из JSON в массив
        curl_close($curl); // Закрываем соединение

        return $response; // Возвращаем ответ
    }
}
