<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */


/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_paymaster', 'order_date');

$dillerID = getUsersGroupID($LINK, $user['uid']);

if ($dillerID != 0) {
    $dilerOptions = readCustomFieldsDealerOptions($LINK, $dillerID, true);

    // Еcли включен у субпровайдера PayMaster
    if (isset($dilerOptions[$systemName . '_on']) AND $dilerOptions[$systemName . '_on'] == '1') {
        // Перезапишем опции
        foreach ($dilerOptions as $key => $value) {
            $systemOptions[$key] = $value;
        }
    }
}

$merchant_id = $systemOptions[$systemName . '_MrchID'];
$market_place_id = $systemOptions[$systemName . '_marketPlace'];

$action_url = "https://lmi.paymaster.ua/";

// TEST-MODE
if (isset($systemOptions[$systemName . '_test']) ? $systemOptions[$systemName . '_test'] : 0) {
    $test_mode = "<input type='hidden' name='LMI_SIM_MODE' value='0' />";
} else {
    $test_mode = "";
}

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('PayMaster.ua');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('POST');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

// TEST-MODE
if (isset($systemOptions[$systemName . '_test']) AND $systemOptions[$systemName . '_test'] == '1') {
    $form->addFieldForm($form->_input('LMI_SIM_MODE', '0'));
}

$form->addFieldForm($form->_input('LMI_MERCHANT_ID', $merchant_id));
$form->addFieldForm($form->_input('LMI_PAYMENT_AMOUNT', $amount));
$form->addFieldForm($form->_input('LMI_PAYMENT_NO', $order_id));
$form->addFieldForm($form->_input('LMI_PAYMENT_DESC', 'Оплата интернета'));

$form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' грн.', 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));
