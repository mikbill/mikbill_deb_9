<?php

if (empty($systemOptions['ukrpays_service_id'])) {
	die('Не указана системная опция ukrpays_service_id');
}

$orderid = startTransaction($LINK, $user, $amount, 'addons_ukrpays');
$actionUrl = empty($systemOptions['ukrpays_urlpay']) ? 'https://ukrpays.com/frontend/frontend.php' : $systemOptions['ukrpays_urlpay'];
$service_id = $systemOptions['ukrpays_service_id'];
$charset = empty($systemOptions['ukrpays_charset']) ? 'UTF-8' : $systemOptions['ukrpays_charset'];
$theme = empty($systemOptions['ukrpays_theme']) ? 'default' : $systemOptions['ukrpays_theme'];
$lang = empty($systemOptions['ukrpays_lang']) ? 'uk' : $systemOptions['ukrpays_lang'];

# Название ПС
$form->setLabelForm('UkrPays');

# Заполняем action URL для формы
$form->setUrlForm($actionUrl);

# POST form
$form->setMethodForm('POST');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_input('fio',$user['fio']));
$form->addFieldForm($form->_input('service_id', $service_id));
$form->addFieldForm($form->_input('charset', $charset));
$form->addFieldForm($form->_input('theme', $theme));
$form->addFieldForm($form->_input('note', 'Uid: '.$user['uid']));
$form->addFieldForm($form->_input('desc', 'internet ' . $user['uid']));
$form->addFieldForm($form->_input('order', $orderid));
$form->addFieldForm($form->_input('amount', $amount));
$form->addFieldForm($form->_input('lang', $lang));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$amount.' грн.', 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));