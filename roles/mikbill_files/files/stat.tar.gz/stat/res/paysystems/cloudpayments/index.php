<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 14.03.2017
 * Time: 9:42
 */

#Формируем ордер
$order_id = startTransaction($LINK, $user, $amount, 'addons_cloudpayments');

if (!empty($systemOptions[$systemName . '_publicId'])) {
    $publicId = $systemOptions[$systemName . '_publicId'];
} else {
    $publicId = "";
}


# Название ПС
$form->setLabelForm('CloudPayments');

# POST form
$form->setMethodForm('POST');

$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $amount, 'Cумма:')));

$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group('<button type="button" id="payButton" class="btn btn-primary btn-block">Оплатить</button>'));

$form->addScriptForm('<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>');
$form->addScriptForm('<script src="https://widget.cloudpayments.ru/bundles/cloudpayments"></script>');
$form->addScriptForm('<script type="text/javascript">
    var payHandler = function () {
        //требуется библиотека jquery
        var widget = new cp.CloudPayments({ startWithButton: false });
        widget.charge({ // options
                publicId: "' . $publicId . '",
                description: "Оплата Internet",
                amount: ' . $amount . ', //сумма
                currency: "RUB",
                invoiceId: "' . $order_id . '", //номер заказа
                accountId: "' . $user['uid'] . '", //плательщик
            },
            function (options) { // success
                //действие при успешном платеже
                 window.open("/main.php?success_mess=Счет успешно пополнен.", "_self"); 
            },
            function (reason, options) { // fail
                //действие при неуспешном платеже
                window.open("/main.php?error_mess=Ошибка. Счет не пополнен.", "_self"); 
            });
    };

    $("#payButton").on("click", payHandler); //кнопка "Оплатить"

</script>');

