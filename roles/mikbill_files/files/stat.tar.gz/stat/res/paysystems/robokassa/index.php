<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */


/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_robokassa', 'order_date');

$description = 'internet ' . $user['uid'];
$encoding = 'UTF-8';

if (!(empty($systemOptions[$systemName . '_test']) and $systemOptions[$systemName . '_test'] == 0)) {
    $action_url = 'http://test.robokassa.ru/Index.aspx';
} else {
    $action_url = 'https://merchant.roboxchange.com/Index.aspx';
}

if (!empty($systemOptions[$systemName . '_MrchLogin'])) {
    $mrh_login = $systemOptions[$systemName . '_MrchLogin'];
} else {
    $mrh_login = "";
}

if (!empty($systemOptions[$systemName . '_mrh_pass1'])) {
    $mrh_pass1 = $systemOptions[$systemName . '_mrh_pass1'];
} else {
    $mrh_pass1 = "";
}

if (!empty($systemOptions[$systemName . '_language'])) {
    $lang = $systemOptions[$systemName . '_language'];
} else {
    $lang = "ru";
}

if (!empty($systemOptions[$systemName . '_order_name'])) {
    $order_name = $systemOptions[$systemName . '_order_name'];
} else {
    $order_name = "Оплата интернета";
}

if (!empty($systemOptions[$systemName . '_sno'])) {
    $sno = $systemOptions[$systemName . '_sno'];
} else {
    $sno = "osn";
}

if (!empty($systemOptions[$systemName . '_tax'])) {
    $tax = $systemOptions[$systemName . '_tax'];
} else {
    $tax = "none";
}

$receiptTmp = array(
    "sno"   => $sno,
    "items" => array(
        "name"     => $order_name,
        "quantity" => 1.0,
        "sum" => $amount,
        "tax" => $tax,
    )
);
$receipt = urlencode(json_encode($receiptTmp));

// Генерируем ChechSum
$sign = md5("$mrh_login:$amount:$order_id:$receipt:$mrh_pass1:shp_uid=" . $user['uid']);

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('RoboKassa');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('POST');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('MrchLogin', $mrh_login));
$form->addFieldForm($form->_input('OutSum', $amount));
$form->addFieldForm($form->_input('InvId', $order_id));
$form->addFieldForm($form->_input('shp_uid', $user['uid']));
$form->addFieldForm($form->_input('Desc', $description));
$form->addFieldForm($form->_input('SignatureValue', $sign));
$form->addFieldForm($form->_input('Encoding', $encoding));
$form->addFieldForm($form->_input('Culture', $lang));

$form->addFieldForm($form->_input('Receipt', $receipt));

$form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' руб.', 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));
