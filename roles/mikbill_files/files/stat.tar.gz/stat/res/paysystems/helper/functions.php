<?php

/**
 * Устанавливаем соединение с БД
 *
 * @param $configFilePath
 *
 * @return mysqli
 */
function connectToDB($configFilePath)
{
    if (file_exists($configFilePath) AND is_readable($configFilePath)) {
        $xml = simplexml_load_file($configFilePath);

        $host = (string)$xml->parameters->mysql->host;
        $db = (string)$xml->parameters->mysql->dbname;
        $user = (string)$xml->parameters->mysql->username;
        $pass = (string)$xml->parameters->mysql->password;
        $charset = 'koi8r';

    } else {
        die('Нет файла конфига или он нечитаем.');
    }

    $opt = array(
        "host"    => $host,
        "user"    => $user,
        "pass"    => $pass,
        "db"      => $db,
        "charset" => $charset
    );

    $db = new SafeMySQL($opt);

    $db->query("SET `character_set_client` = 'koi8r'");
    $db->query("SET NAMES koi8r");
    $db->query("SET CHARSET koi8r;");
    $db->query("CALL connect_switch_to_KOI8();");

    
    return $db;
}

function billingInitSystemOptions(SafeMySQL $db, $condition = '')
{
    $result = array();

    if (!empty($condition)) {
        $resultTmp = $db->getAll("SELECT * FROM ?n WHERE ?p", 'system_options', $condition);
    } else {
        $resultTmp = $db->getAll("SELECT * FROM ?n", 'system_options');
    }

    if (!empty($resultTmp)) {
        foreach ($resultTmp as $row) {
            $result[$row['key']] = iconv('KOI8-R', 'UTF-8', $row['value']);
        }
    }

    return $result;
}

function billingInitSystemOptionsByKey(SafeMySQL $db, $keyCondition)
{
    $condition = $db->parse("`key` LIKE ?s", $keyCondition);

    $result = billingInitSystemOptions($db, $condition);

    return $result;
}

function getUsersGroupID(SafeMySQL $db, $uid)
{
    $groupid = $db->getOne("SELECT `usersgroupid` FROM `usersgroups_users` WHERE `uid` = ?s", $uid);

    if ($groupid) {
        return $groupid;
    } else {
        return 0;
    }
}

function startTransaction(SafeMySQL $db, $user, $amount, $table, $columnDate = 'server_time', $columnAmount = 'amount')
{
    # занести запись в платежи
    $db->query("INSERT INTO ?n (`uid`, ?n, ?n ) VALUES (?s, ?s, NOW() )", $table, $columnAmount, $columnDate, $user['uid'], $amount);

    return $db->insertId();
}

function updateOrderID(SafeMySQL $db, $orderID, $column, $value, $table)
{
    # обновить существующую запись в платежи
    $db->query("UPDATE ?n SET ?n = ?s WHERE `order_id` = ?s ;", $table, $column, $value, $orderID);
}


function readCustomFieldsDealerOptions(SafeMySQL $db, $dealer = 0, $notExt = false)
{
    $result = array();

    $resultTmp = $db->getAll("SELECT * FROM `usersgroups_extended_fields` WHERE `id` = ?s", $dealer);

    if (!empty($resultTmp)) {
        foreach ($resultTmp as $row) {

            if ($notExt) {
                $row['key'] = str_replace("ext_", "", $row['key']);
            }

            $result[$row['key']] = iconv('KOI8-R', 'UTF-8', $row['value']);
        }
    }

    return $result;
}

/**
 * Получаем данные абонента из POST
 *
 * @return array
 */
function getUserDataFromPOST()
{
    $user = array(
        'fio'   => '',
        'email' => '',
        'phone' => '',
    );

    # UID
    if (isset($_POST['uid'])) {
        $user['uid'] = intval($_POST['uid']);
    } elseif (isset($_GET['uid'])) {
        $user['uid'] = intval($_GET['uid']);
    } else {
        die('User not defined');
    }

    # ФИО
    if (isset($_POST['fio'])) {
        $user['fio'] = $_POST['fio'];
    } elseif (isset($_GET['fio'])) {
        $user['fio'] = $_GET['fio'];
    }

    # e-mail
    if (isset($_POST['email'])) {
        $user['email'] = $_POST['email'];
    } elseif (isset($_GET['email'])) {
        $user['email'] = $_GET['email'];
    }

    # phone
    if (isset($_POST['phone'])) {
        $user['phone'] = $_POST['phone'];
    } elseif (isset($_GET['phone'])) {
        $user['phone'] = $_GET['phone'];
    }

    return $user;
}

function getUser(SafeMySQL $db, $uid, $tables = array(
    1,
    2
))
{

    $user = false;

    $usersTables = array(
        1 => 'users',
        2 => 'usersfreeze',
        3 => 'usersblok',
        4 => 'usersdel'
    );

    foreach ($tables as $tableID) {

        $user = $db->getRow("SELECT `uid`, `deposit`, `fio`, `user`, `numdogovor` FROM ?n WHERE `uid` = ?s ;", $usersTables[$tableID], $uid);

        if (!empty($user)) {
            break;
        }
    }

    return $user;
}


/**
 * Добавляет абоненту баланс
 *
 * @param        $uid
 * @param        $amount
 * @param mysqli $LINK
 * @param        $systemOptions
 * @param        $bughtypeid
 * @param array $tables
 */
function addUserBalance($uid, $amount, SafeMySQL $db, &$systemOptions, $bughtypeid, $tables = array(
    1,
    2
))
{
    $usersTables = array(
        1 => 'users',
        2 => 'usersfreeze',
        3 => 'usersblok',
        4 => 'usersdel'
    );

    foreach ($tables as $tableID) {

        $user = $db->getRow("SELECT `uid`, `deposit`, `fio`, `user`,  `local_mac` FROM ?n WHERE `uid` = ?s ;", $usersTables[$tableID], $uid);

        if (!empty($user)) {
            $deposit = $user['deposit'];
            $mac = $user['local_mac'];

            # увеличиваем депозит абонента
            $db->query("UPDATE ?n SET `deposit` = `deposit` + ?p WHERE `uid` = ?s", $usersTables[$tableID], $amount, $uid);

            # занести запись в логи платежей
            $db->query("INSERT INTO `bugh_plategi_stat` ( uid , date , who , bughtypeid , before_billing , summa , comment ) VALUES (?s, NOW(),NULL, ?s, ?s,?s,'' )", $uid, $bughtypeid, $deposit, $amount);

            # @TODO всяко разно

            $script_dir = './sys/scripts/mb_after_pay.sh ';
            # вызываем скрипт после пополнения счёта из админки
            $execCommand = $systemOptions['sudo'] . ' ' . $script_dir . ' ' . $uid . ' ' . $mac;
            exec($execCommand);

            break;
        }
    }
}

function getPostParam($param, $default = null)
{
    if (isset($_POST[$param])) {
        return $_POST[$param];
    } elseif (isset($_GET[$param])) {
        return $_GET[$param];
    } else {
        return $default;
    }
}

function xmlParser($input_xml)
{
    $xml = simplexml_load_string($input_xml);
    $json = json_encode($xml);
    $result = json_decode($json, true);

    return $result;
}

/**
 * Округляет/преобразует строковое значение $sum в тип float с 2-я знаками после запятой.
 *
 * @param string $sum
 * @return float
 */
function to_float($sum)
{
    $sum = round(floatval($sum), 2);
    $sum = sprintf('%01.2f', $sum);

    if (substr($sum, -1) == '0') {
        $sum = sprintf('%01.1f', $sum);
    }

    return $sum;
}

/**
 * Формируем страницу контентом и заголовком страницы
 *
 * @param $response
 * @param $title
 *
 * @return string
 */
function setResponse($response, $title = 'Пополнение счёта')
{
    return '<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>' . $title . '</title>
</head>
<body>
	<table align="center" height="100%">
		<tr><td valign="middle" align="center">
		' . $response . '
		</td></tr>
	</table>
</body></html>';
}
