<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 03.06.2017
 * Time: 0:22
 *
 * error:
 *  1 = отстутсвуют парметры поиска
 *  2 = отсутсвует ключ в БД
 *  3 = неверная подпись запроса
 *
 */
class PayApiClass
{
    private $db = null;
    private $systemOptions = array();

    function __construct($systemOptions = array(), SafeMySQL $db = null)
    {
        $this->db = $db;
        $this->systemOptions = $systemOptions;

        $inputData = $this->getParams();
        $this->proceedRequest($inputData);
    }

    private function proceedRequest($inputData)
    {
        if (!empty($this->systemOptions['payment_api_key'])) {

            if (!empty($inputData['data_api']) AND !empty($inputData['action']) AND !empty($inputData['sign']) AND !empty($inputData['salt'])) {

                $check_signature = self::check_signature($inputData, $inputData['sign'], $inputData['salt'], $this->systemOptions['payment_api_key']);

                if ($check_signature) {

                    if ($inputData['action'] == 'search') {
                        $this->searchUser($inputData);
                    }

                } else {
                    $response = array(
                        "success" => false,
                        "code"    => 3,
                        "data"    => array()
                    );
                    $this->responseJSON($response);
                }

            } else {
                $response = array(
                    "success" => false,
                    "code"    => 1,
                    "data"    => array()
                );
                $this->responseJSON($response);
            }

        } else {
            $response = array(
                "success" => false,
                "code"    => 2,
                "data"    => array()
            );
            $this->responseJSON($response);
        }

    }

    private function searchUser($inputData)
    {
        $account = $inputData['account'];

        $queue = $this->get_search_queue_for_payment_system($inputData);
        $abon = $this->search_user_with_priorities($account, $queue);


        $response = array(
            "success" => true,
            "code"    => 0,
            "data"    => $abon
        );
        $this->responseJSON($response);
    }

    private function search_user_with_priorities($account, $queue)
    {
        $res = array();

        for ($i = 1; $i < 6; $i++) {
            if (isset($queue[$i])) {
                $res = $this->$queue[$i]($account);
            }

            if (!empty($res))
                break;
        }


        return $res;
    }


    private function user_proper_by_login_users_usersfreezed($login)
    {
        $data = $this->db->getRow("SELECT `uid`, `deposit`, `fio`, `user`, `numdogovor` FROM `users` WHERE `user` = ?s", $login);

        if (empty($data)) {
            $data = $this->db->getRow("SELECT `uid`, `deposit`, `fio`, `user`, `numdogovor` FROM `usersfreeze` WHERE `user` = ?s", $login);
        }

        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = iconv('KOI8-R', 'UTF-8', $value);
            }
        }

        return $data;
    }


    private function user_proper_by_numdogovor_users_freezed($numdogovor)
    {

        $data = $this->db->getRow("SELECT `uid`, `deposit`, `fio`, `user`, `numdogovor` FROM `users` WHERE `numdogovor` = ?s", $numdogovor);

        if (empty($data)) {
            $data = $this->db->getRow("SELECT `uid`, `deposit`, `fio`, `user`, `numdogovor` FROM `usersfreeze` WHERE `numdogovor` = ?s", $numdogovor);
        }

        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = iconv('KOI8-R', 'UTF-8', $value);
            }
        }

        return $data;
    }

    private function user_proper_by_uid_users_freezed($uid)
    {
        $data = $this->db->getRow("SELECT `uid`, `deposit`, `fio`, `user`, `numdogovor` FROM `users` WHERE `uid` = ?s", $uid);

        if (empty($data)) {
            $data = $this->db->getRow("SELECT `uid`, `deposit`, `fio`, `user`, `numdogovor` FROM `usersfreeze` WHERE `uid` = ?s", $uid);
        }

        if (!empty($data)) {
            foreach ($data as $key => $value) {
                $data[$key] = iconv('KOI8-R', 'UTF-8', $value);
            }
        }

        return $data;
    }

    private function get_search_queue_for_payment_system($inputData)
    {
        $queue = array();

        // Поиск по UIDу
        if (isset($inputData['search_uid_prio']) AND (int)$inputData['search_uid_prio'] != 0) {
            if (!isset($queue[(int)$inputData['search_uid_prio']])) {
                $queue[(int)$inputData['search_uid_prio']] = 'user_proper_by_uid_users_freezed';
            } else {
                $queue[] = 'user_proper_by_uid_users_freezed';
            }
        }

        // Поиск по user (login)
        if (isset($inputData['search_login_prio']) AND (int)$inputData['search_login_prio'] != 0) {
            if (!isset($queue[(int)$inputData['search_login_prio']])) {
                $queue[(int)$inputData['search_login_prio']] = 'user_proper_by_login_users_usersfreezed';
            } else {
                $queue[] = 'user_proper_by_login_users_usersfreezed';
            }
        }

        // Поиск по номеру договора
        if (isset($inputData['search_dogovor_prio']) AND (int)$inputData['search_dogovor_prio'] != 0) {
            if (!isset($queue[(int)$inputData['search_dogovor_prio']])) {
                $queue[(int)$inputData['search_dogovor_prio']] = 'user_proper_by_numdogovor_users_freezed';
            } else {
                $queue[] = 'user_proper_by_numdogovor_users_freezed';
            }
        }

        return $queue;
    }


    public static function get_salt()
    {
        return uniqid(mt_rand(), true);
    }

    public static function check_signature($array, $sign, $salt, $secret_key)
    {
        $sig = self::make_signature_string($array, $salt, $secret_key);

        if ($sig == $sign) {
            return true;
        } else {
            return false;
        }
    }

    public static function make_signature_string($array, $salt, $secret_key)
    {
        // ансетим подпись и соль, если она уже присутствовала в массиве запроса
        if (isset($array['sign'])) {
            unset($array['sign']);
        }

        if (isset($array['salt'])) {
            unset($array['salt']);
        }

        // 1. отсортируем массив по ключам, рекурсивно
        self::ksort_recursive($array);

        $values_str = implode(';', array_values($array));
        $concat_string = $values_str . ';' . $salt . ';' . $secret_key;

        return hash('sha256', $concat_string);
    }

    public static function ksort_recursive(&$array, $sort_flags = SORT_REGULAR)
    {
        // если это не массив - сразу вернем false
        if (!is_array($array)) {
            return false;
        }

        ksort($array, $sort_flags);

        foreach ($array as &$arr) {
            self::ksort_recursive($arr, $sort_flags);
        }

        return true;
    }

    private function getParams()
    {
        $params_input = array();

        if (!empty($_POST) AND is_array($_POST)) {
            foreach ($_POST as $k => $v) {
                $params_input[$k] = $v;
            }
        }
        if (!empty($_GET) AND is_array($_GET)) {
            foreach ($_GET as $k => $v) {
                $params_input[$k] = $v;
            }
        }

        $postData = file_get_contents('php://input');
        $jsonData = json_decode($postData, true);
        if (!empty($jsonData)) {
            $params_input = array_merge($params_input, $jsonData);
        }

        return $params_input;
    }


    private function responseJSON($response, $code = 200, $message = 'OK')
    {
        header("HTTP/1.1 " . $code . " " . $message);
        header('Content-type: application/json ; charset=utf-8');

        $encoded = json_encode($response);
        exit($encoded);
    }


    private function roundAmount($amount)
    {
        return round($amount, 2);
    }
}
