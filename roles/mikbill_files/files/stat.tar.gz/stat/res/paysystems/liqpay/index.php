<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */

/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_liqpay', 'order_date');


$dillerID = getUsersGroupID($LINK, $user['uid']);

if($dillerID != 0){
    $dilerOptions = readCustomFieldsDealerOptions($LINK, $dillerID, true);

    // Еcли включен у субпровайдера LiqPay
    if(isset($dilerOptions['do_liqpay_terminal']) AND $dilerOptions['do_liqpay_terminal'] == '1' ){
        // Перезапишем опции
        foreach ($dilerOptions as $key => $value){
            $systemOptions[$key] = $value;
        }
    }
}


$public_key = $systemOptions['merchant_id'];
$private_key = $systemOptions['merc_sign_other'];
$curency = $systemOptions['liqpay_curency'];
$url_result = $systemOptions['url_result'];
$url_server = $systemOptions['url_server'];

$fio2 = $user['uid'];
$description = $user['uid'];

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('LiqPay');

# POST form
$form->setMethodForm('POST');

#По старой схеме XML . Deprecated
if (!(isset($systemOptions[$systemName . '_v3']) and $systemOptions[$systemName . '_v3'] == 1)) {

    $action_url = 'https://www.liqpay.com/?do=clickNbuy';

    $xml = "<request>
      <version>1.2</version>
      <merchant_id>" . $public_key . "</merchant_id>
      <result_url>" . $url_result . "</result_url>
      <server_url>" . $url_server . "</server_url>
      <order_id>" . $order_id . "</order_id>
      <amount>" . $amount . "</amount>
      <currency>" . $curency . "</currency>
      <description>" . $description . "</description>
      <default_phone></default_phone>
      <pay_way></pay_way>
      <goods_id></goods_id>
</request>";

    $sign = base64_encode(sha1($private_key . $xml . $private_key, 1));
    $xml_encoded = base64_encode($xml);

    # Заполняем action URL для формы
    $form->setUrlForm($action_url);

    # заполняем форму полями
    $form->addFieldForm($form->_h('Информация по платежу:'));
    $form->addFieldForm($form->_hr());

    $form->addFieldForm($form->_input('operation_xml', $xml_encoded));
    $form->addFieldForm($form->_input('signature', $sign));

    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' ' . $curency, 'Cумма:')));
    $form->addFieldForm($form->_hr());
    $form->addFieldForm($form->_group($form->_button()));

} else {

    $_checkout_url = 'https://www.liqpay.ua/api/3/checkout';
    $params = array(
        'public_key'  => $public_key,
        'action'      => 'pay',
        'amount'      => $amount,
        'currency'    => $curency,
        'description' => $description,
        'order_id'    => $order_id,
        'result_url'  => $url_result,
        'server_url'  => $url_server,
        'version'     => '3'
    );

    $data = base64_encode(json_encode($params));
    $signature = base64_encode(sha1($private_key . $data . $private_key, 1));

    # Заполняем action URL для формы
    $form->setUrlForm($_checkout_url);

    # заполняем форму полями
    $form->addFieldForm($form->_h('Информация по платежу:'));
    $form->addFieldForm($form->_hr());

    $form->addFieldForm($form->_input('data', $data));
    $form->addFieldForm($form->_input('signature', $signature));

    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' ' . $curency, 'Cумма:')));
    $form->addFieldForm($form->_hr());
    $form->addFieldForm($form->_group($form->_button()));
}

