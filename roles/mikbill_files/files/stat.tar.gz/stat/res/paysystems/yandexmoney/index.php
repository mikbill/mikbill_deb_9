<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 01.03.2017
 * Time: 15:14
 */


if (!empty($systemOptions[$systemName . '_success_url'])) {
    $successURL = $systemOptions[$systemName . '_success_url'];
} else {
    $successURL = "";
}

if (!empty($systemOptions[$systemName . '_receiver'])) {
    $receiver = $systemOptions[$systemName . '_receiver'];
} else {
    $receiver = "";
}

$actionUrl = 'https://money.yandex.ru/quickpay/confirm.xml';

$paymentType = array(
    "PC" => "Со счета в Яндекс.Деньгах",
    "AC" => "С банковской карты",
//    "MC" => "Cо счета мобильного телефона"
);

# Название ПС
$form->setLabelForm('Яндекс.Деньги');

# Заполняем action URL для формы
$form->setUrlForm($actionUrl);

# Заполняем action URL для формы
$form->setUrlForm($actionUrl);

# POST form
$form->setMethodForm('POST');

$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('receiver', $receiver));
$form->addFieldForm($form->_input('successURL', $successURL));
$form->addFieldForm($form->_input('targets', 'Оплата услуг Internet'));
$form->addFieldForm($form->_input('quickpay-form', 'donate'));
$form->addFieldForm($form->_input('label', $user['uid']));
$form->addFieldForm($form->_input('sum', $amount));

$form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $amount, 'Cумма:')));
$form->addFieldForm($form->_group($form->_selectLabel('paymentType', $paymentType, 'Тип оплаты:', false)));

$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));