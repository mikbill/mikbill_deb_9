<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */


/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_isbank');

$client_id = $systemOptions[$systemName . '_client_id'];
$result_url = $systemOptions[$systemName . '_result_url'];
$action_url = $systemOptions[$systemName . '_action_url'];
$storekey =  $systemOptions[$systemName . '_store_key'];

$rnd = microtime();
$taksit = "";
$islemtipi = "Auth";

$hashstr = $client_id . $order_id . $amount . $result_url . $result_url . $islemtipi . $taksit . $rnd . $storekey; //g�venlik ama�li hashli deger
$hash = base64_encode(pack('H*', sha1($hashstr)));

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('ISBANK');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('POST');

# заполняем форму полями
$form->addFieldForm($form->_h('Ödeme ile ilgili bilgiler:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('clientid', $client_id));
$form->addFieldForm($form->_input('amount', $amount));
$form->addFieldForm($form->_input('oid', $order_id));
$form->addFieldForm($form->_input('okUrl', $result_url));
$form->addFieldForm($form->_input('failUrl', $result_url));
$form->addFieldForm($form->_input('islemtipi', $islemtipi));
$form->addFieldForm($form->_input('taksit', $taksit));
$form->addFieldForm($form->_input('rnd', $rnd));
$form->addFieldForm($form->_input('hash', $hash));

$form->addFieldForm($form->_input('storetype', '3d_pay_hosting'));
$form->addFieldForm($form->_input('refreshtime', '10'));
$form->addFieldForm($form->_input('lang', 'tr'));
$form->addFieldForm($form->_input('currency', '949'));
$form->addFieldForm($form->_input('firmaadi', 'Benim Firmam'));

$form->addFieldForm($form->_input('Fismi', 'is'));

//$form->addFieldForm($form->_input('faturaFirma', 'faturaFirma'));
//$form->addFieldForm($form->_input('Fadres', 'XXX'));
//$form->addFieldForm($form->_input('Fadres2', 'XXX'));
//$form->addFieldForm($form->_input('Fil', 'XXX'));

//$form->addFieldForm($form->_input('Filce', 'XXX'));
//$form->addFieldForm($form->_input('Fpostakodu', 'postakod93013'));
//$form->addFieldForm($form->_input('tel', 'XXX'));
//$form->addFieldForm($form->_input('fulkekod', 'tr'));

//$form->addFieldForm($form->_input('nakliyeFirma', 'na fi'));
//$form->addFieldForm($form->_input('tismi', 'XXX'));
//$form->addFieldForm($form->_input('tadres', 'XXX'));
//$form->addFieldForm($form->_input('tadres2', 'XXX'));

//$form->addFieldForm($form->_input('til', 'XXX'));
//$form->addFieldForm($form->_input('tilce', 'XXX'));
//$form->addFieldForm($form->_input('tpostakodu', 'ttt postakod93013'));
//$form->addFieldForm($form->_input('tulkekod', 'usa'));

//$form->addFieldForm($form->_input('itemnumber1', 'a1'));
//$form->addFieldForm($form->_input('productcode1', 'a2'));
//$form->addFieldForm($form->_input('qty1', '3'));
//$form->addFieldForm($form->_input('desc1', 'a4 desc'));
//$form->addFieldForm($form->_input('id1', 'a5'));

//$form->addFieldForm($form->_input('price1', '6.25'));
//$form->addFieldForm($form->_input('price1', '7.50'));

$form->addFieldForm($form->_group($form->_inputLabel(false,$user['fio'], 'Soyisim, İsim:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$amount.' TL', 'Toplam:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button("Devam")));
