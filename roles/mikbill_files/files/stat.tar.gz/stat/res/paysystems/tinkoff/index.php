<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 08.08.2017
 * Time: 9:19
 */

/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_tinkoff');

$description = 'Internet UID ' .$user['uid'];

if (!empty($systemOptions[$systemName . '_terminal_key'])){
    $terminalKey =  $systemOptions[$systemName . '_terminal_key'];
}else{
    $terminalKey = "";
}

if (!empty($systemOptions[$systemName . '_secret_key'])){
    $secretKey =  $systemOptions[$systemName . '_secret_key'];
}else{
    $secretKey = "";
}

require(dirname(__FILE__) . '/lib/TinkoffMerchantAPI.php');

$api = new TinkoffMerchantAPI($terminalKey, $secretKey);

$params = array(
    'OrderId' => $order_id,
    'Amount'  => $amount * 100,
    'Description'  => $description,
);

$api->init($params);


/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('Tinkoff');

# POST form
$form->setMethodForm('GET');

if ($api->error){
    # заполняем форму полями
    $form->addFieldForm($form->_h('Ошибка. ' . $api->error));
    $form->addFieldForm($form->_hr());
}else{

    # Заполняем action URL для формы
    $form->setUrlForm($api->paymentUrl);

    # заполняем форму полями
    $form->addFieldForm($form->_h('Информация по платежу:'));
    $form->addFieldForm($form->_hr());

    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' руб.', 'Cумма:')));
    $form->addFieldForm($form->_hr());
    $form->addFieldForm($form->_group($form->_button()));
}
