<?php

$response = '<form action="/pay.php?system=stripe&act=pay" method="POST">
	Pay ' . $systemOptions['stripe_currency_symbol'] . $amount . '<br />
	<br />
  <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
          data-key="' . $systemOptions['stripe_publishable_key'] . '"
          data-amount="' . round($amount * 100, 0) . '"
		  data-description="Internet Service"
		  data-name="ISP"
		  data-currency="' . $systemOptions['stripe_currency'] . '"
		  data-email="' . $user['email'] . '"
		  ></script>
	<input hidden name="uid" value="' . $user['uid'] . '">
	<input hidden name="fio" value="' . $user['fio'] . '">
	<input hidden name="amount" value="' . $amount . '">
</form>';
