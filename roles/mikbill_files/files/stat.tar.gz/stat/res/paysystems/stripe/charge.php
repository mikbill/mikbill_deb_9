<?php
require_once(dirname(__FILE__) . DS . 'init.php');

\Stripe\Stripe::setApiKey($systemOptions['stripe_secret_key']);
$token = $_POST['stripeToken'];

# не создаём покупателей, а снимаем сразу по токену
//$customer = \Stripe\Customer::create(array(
//                                          'email' => $email,
//                                          'card'  => $token
//                                     ));

try {
	$charge = \Stripe\Charge::create(array(
	                                      //                                      'customer' => $customer->id,
	                                      'card'     => $token,
	                                      'amount'   => round($amount * 100, 0),
	                                      'currency' => $systemOptions['stripe_currency'],
	                                      'description' => 'OliveNet ISP'
	                                 ));

	# если успешно оплачено
	if ($charge->paid) {
	
		if(!empty($systemOptions['stripe_go_back'])){
			$response = '<h1>Successfully charged ' . $systemOptions['stripe_currency_symbol'] . $amount . '!</h1>
		<h2><a href="' . $systemOptions['stripe_go_back'] . '">Go Back to Cabinet</a></h2>

		<script type="text/javascript">
			setTimeout(function(){location.href="' . $systemOptions['stripe_go_back'] . '"},500);
		</script>

		';
		}else{
			$response = '<h1>Successfully charged ' . $systemOptions['stripe_currency_symbol'] . $amount . '!</h1>
		<h2><a href="main.php">Go Back to Cabinet</a></h2>';
		}

		# пополняем абонента по UID'у
		addUserBalance($user['uid'], $amount, $LINK, $systemOptions, 87);

		$query = 'INSERT INTO `addons_stripe` (`uid` , `amount` , `txn_date`) VALUES (' . $user['uid'] . ', ' . $amount . ', NOW());';
		# занесём платёж в подробный отчёт
		$LINK->query($query);
	} else {
		$response = '<h1>Something gone wrong!</h1>';
	}
} catch (Exception $e) {
	# поймали ошибку - отобразим её
	$error = $e->getMessage();
	$response = '<h1>' . $error . '</h1>
	<h2><a href="javascript:history.back()">Go Back</a></h2>';
}
