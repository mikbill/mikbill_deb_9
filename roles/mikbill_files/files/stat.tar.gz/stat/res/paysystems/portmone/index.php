<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */

/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_portmone');
$payee_id = $systemOptions[$systemName . '_payee_id'];
$description = 'Internet';
$action_url = 'https://www.portmone.com.ua/gateway/';

if (!empty($systemOptions[$systemName . '_success_url'])){
    $success_url =  $systemOptions[$systemName . '_success_url'];
}else{
    $success_url = "http://example.com/pay/ok";
}

if (!empty($systemOptions[$systemName . '_failure_url'])){
    $failure_url =  $systemOptions[$systemName . '_failure_url'];
}else{
    $failure_url = "http://example.com/pay/no";
}

if (!empty($systemOptions[$systemName . '_lang'])){
    $lang =  $systemOptions[$systemName . '_lang'];
}else{
    $lang = "ru";
}

if (!empty($systemOptions[$systemName . '_encoding'])){
    $encoding =  $systemOptions[$systemName . '_encoding'];
}else{
    $encoding = "UTF-8";
}


/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('Portmone');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('POST');


# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('payee_id', $payee_id));
$form->addFieldForm($form->_input('shop_order_number', $order_id));
$form->addFieldForm($form->_input('bill_amount', $amount));
$form->addFieldForm($form->_input('description', $description));
$form->addFieldForm($form->_input('success_url', $success_url));
$form->addFieldForm($form->_input('failure_url', $failure_url));
$form->addFieldForm($form->_input('lang', $lang));
$form->addFieldForm($form->_input('encoding', $encoding));

$form->addFieldForm($form->_group($form->_inputLabel(false,$user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$amount.' грн.', 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));
