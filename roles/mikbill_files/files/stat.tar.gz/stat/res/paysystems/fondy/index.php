<?php
/*
Oplata.com Dashboard
*/

#Формируем ордер
$order_id = startTransaction($LINK, $user, $amount, 'addons_fondy');
$order_desc = "Internet";
$action_url = "https://api.fondy.eu/api/checkout/redirect/";

// Приводим в копейки
$amount_pay = $amount * 100;

#TODO !!!
//$order_id = $order_id.time();

$params = array(
	'order_id'            => $order_id,
	'merchant_id'         => $systemOptions[$systemName . '_merchant_id'],
	'order_desc'          => $order_desc,
	'amount'              => $amount_pay,
	'currency'            => $systemOptions[$systemName . '_currency'],
	'server_callback_url' => $systemOptions[$systemName . '_server_callback_url'],
	'response_url'        => $systemOptions[$systemName . '_response_url']
);

$signature = getSignature($params, $systemOptions[$systemName . '_secret_seed']);

function getSignature($data, $password, $encoded = true)
{
	$data = array_filter($data, function($var) {
		return $var !== '' && $var !== null;
	});

	ksort($data);

	$str = $password;
	foreach ($data as $k => $v) {
		$str .= '|' . $v;
	}

	if ($encoded) {
		return sha1($str);
	} else {
		return $str;
	}
}

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('Fondy');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('POST');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('order_id',$order_id));
$form->addFieldForm($form->_input('order_desc', $order_desc));
$form->addFieldForm($form->_input('server_callback_url', $systemOptions[$systemName . '_server_callback_url']));
$form->addFieldForm($form->_input('response_url', $systemOptions[$systemName . '_response_url']));
$form->addFieldForm($form->_input('currency', $systemOptions[$systemName . '_currency']));
$form->addFieldForm($form->_input('amount', $amount_pay));
$form->addFieldForm($form->_input('signature', $signature));
$form->addFieldForm($form->_input('merchant_id', $systemOptions[$systemName . '_merchant_id']));

$form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' грн.', 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));