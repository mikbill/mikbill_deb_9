<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */

//  SimpePay class
require(dirname(__FILE__) . '/lib/simplepay.class.php');

/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_simplepay');

if (!empty($systemOptions[$systemName . '_shopID'])) {
    $shopID = $systemOptions[$systemName . '_shopID'];
} else {
    $shopID = "";
}

if (!empty($systemOptions[$systemName . '_secretKey'])) {
    $secretKey = $systemOptions[$systemName . '_secretKey'];
} else {
    $secretKey = "";
}
if (!empty($systemOptions[$systemName . '_hashAlgo'])) {
    $hashAlgo = $systemOptions[$systemName . '_hashAlgo'];
} else {
    $hashAlgo = "MD5";
}

$paymentData = array(
    "sp_outlet_id"          => $shopID,
    "sp_order_id"           => $order_id,
    "sp_amount"             => $amount,
    "sp_description"        => 'internet ' . $user['uid'],
    "sp_user_ip"            => $_SERVER['REMOTE_ADDR'],
    "sp_user_name"          => $user['fio'],
    "sp_user_contact_email" => $user['email'],
    "sp_user_phone"         => $user['phone'],

);

$simplePay = new simplePay();
$simplePay->set($shopID, $secretKey, $hashAlgo);
$data_result = $simplePay->createPayment($paymentData);

if (!empty($data_result['sp_error_description'])) {
    $errorText = $data_result['sp_error_description'];
} else {
    $errorText = 'Попробуйте позже...';
}

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

if (!empty($data_result['sp_redirect_url'])) {

    # Название ПС
    $form->setLabelForm('SimplePay');

    # Заполняем action URL для формы
    $form->setUrlForm($data_result['sp_redirect_url']);

    # POST form
    $form->setMethodForm('POST');

    # заполняем форму полями
    $form->addFieldForm($form->_h('Информация по платежу:'));
    $form->addFieldForm($form->_hr());

    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
    $form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' руб.', 'Cумма:')));
    $form->addFieldForm($form->_hr());
    $form->addFieldForm($form->_group($form->_button()));
} else {

    # Название ПС
    $form->setLabelForm('SimplePay');

    # заполняем форму полями
    $form->addFieldForm($form->_h('Ошибка. ' . $errorText));
    $form->addFieldForm($form->_hr());
}

