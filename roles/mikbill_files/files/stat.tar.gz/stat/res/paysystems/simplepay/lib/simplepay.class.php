<?php

/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 22.11.2016
 * Time: 13:41
 */
class simplePay
{
    private
        $outlet_id,
        $secret_key,
        $hash_algo = "MD5";


    protected
        $strong_ssl = true;


    static
        /**
         * URL для совершения платежа в обычном режиме
         */
        $_SP_Payment_URL_Secure = "https://api.simplepay.pro/sp/payment",
        /**
         * URL для совершения платежа в режиме прямого взаимодействия
         */
        $_SP_Payment_URL_Direct_Secure = "https://api.simplepay.pro/sp/init_payment";


    public function set($sp_outlet_id, $secret_key, $hash_algo)
    {
        $this->outlet_id = $sp_outlet_id;
        $this->secret_key = $secret_key;
        $this->hash_algo = $hash_algo;
    }

    public function createPayment($paymentData)
    {
        return $this->make_sp_json_request(
            $paymentData,
            self::$_SP_Payment_URL_Direct_Secure
        );
    }

    /**
     * Создание и отправка подписанного JSON-запроса к API SimplePay и разбор
     * полученного JSON-ответа в массив
     * @param type $data_array
     * @param type $request_url
     * @return boolean
     */
    private function make_sp_json_request($data_array, $request_url){

        $arrReq = $data_array;

        // Параметры безопасности сообщения. Необходима генерация sp_salt и подписи сообщения.
        $arrReq['sp_salt'] = rand(21, 43433);

        // подписываем запрос
        $script_name = basename($request_url);
        $arrReq['sp_sig'] = $this->make_signature_string_request($arrReq, $script_name);

        // Подготовим и отправим JSON-запрос
        $answer = $this->curl_post(
            $request_url,
            array('sp_json' => json_encode($arrReq)),
            $this->strong_ssl
        );

        // Раскодируем полученный JSON-ответ
        $decoded_answer = json_decode($answer,true);

        if(is_array($decoded_answer)){
            return $decoded_answer;
        } else{
            return false;
        }
    }




    /**
     * Генератор подписи для запроса платежа
     * @param array $array Ассоациативный массив с параметрами для подписи
     * @param string $script_name Имя скрипта, к которому будет адресовано подписываемое сообщение
     * @return string
     */
    private function make_signature_string_request($array, $script_name) {
        return self::make_signature_string(
            $array,
            $script_name,
            $this->secret_key,
            $this->hash_algo);
    }

    /**
     * Формирование подписи по алгоритму SimplePay.
     * @param array $array Ассоациативный массив с параметрами для подписи
     * @param string $script_name Имя скрипта, к которому будет адресовано подписываемое сообщение
     * @param string $secret_key Секретный ключ торговой точки
     * @param string $hash_algo Алгоритм хеширования: MD5 (по-умолчанию), SHA256, SHA512.
     * @return string Полученная подпись
     */
    public static function make_signature_string($array, $script_name, $secret_key, $hash_algo = 'MD5') {

        // ансетим подпись, если она уже присутствовала в массиве запроса
        unset($array['sp_sig']);

        // 1. отсортируем массив по ключам, рекурсивно
        self::ksort_recursive($array);

        $values_str = implode(';', array_values($array));

        $concat_string = $script_name . ';' . $values_str . ';' . $secret_key;

        if (strtolower($hash_algo) == 'md5') {
            return md5($concat_string);
        } else {
            return hash($hash_algo, $concat_string);
        }
    }

    /**
     * Статический метод для рекурсивной сортировки массива по именам ключей
     * @param array $array входящий массив для сортировки
     * @param int $sort_flags Флаги для сортировки, по-умолчанию - SORT_REGULAR
     * @return boolean
     */
    public static function ksort_recursive(&$array, $sort_flags = SORT_REGULAR) {
        // если это не массив - сразу вернем false
        if (!is_array($array)) {
            return false;
        }

        ksort($array, $sort_flags);

        foreach ($array as &$arr) {
            self::ksort_recursive($arr, $sort_flags);
        }

        return true;
    }


    /**
     * Отправка данных POST-запросом через CURL, возвращает тело ответа
     * @param string $url URL запрашиваемого ресурса
     * @param array $params Массив с параметрами
     * @param boolean $verifypeer Опция CURL CURLOPT_SSL_VERIFYPEER (по умолчанию false)
     * @return string
     */
    private function curl_post($url, $params, $verifypeer = false) {
        if ($curl = curl_init()) {
            $query = http_build_query($params);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, $verifypeer);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $query);
            $out = curl_exec($curl);
            curl_close($curl);
            return $out;
        } else {
            return false;
        }
    }
}