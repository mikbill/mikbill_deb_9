<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */


/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */


$dillerID = getUsersGroupID($LINK, $user['uid']);

if ($dillerID != 0) {
    $dilerOptions = readCustomFieldsDealerOptions($LINK, $dillerID, true);

    // Еcли включен у субпровайдера Privat24
    if (isset($dilerOptions['do_privat_v2'], $dilerOptions['privat_v2_lk']) AND $dilerOptions['do_privat_v2'] == '1'
        AND $dilerOptions['privat_v2_lk'] == '1'
    ) {
        // Перезапишем опции
        foreach ($dilerOptions as $key => $value) {
            $systemOptions[$key] = $value;
        }
    }
}

if (!empty($systemOptions['privat_v2_static_token'])) {
    $privat_v2_static_token = $systemOptions['privat_v2_static_token'];
} else {
    $privat_v2_static_token = '';
}

$action_url = "https://my-payments.privatbank.ua/mypayments/customauth/identification/fp/static";

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('ПриватБанк');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('GET');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('staticToken', $privat_v2_static_token));
$form->addFieldForm($form->_input('acc', $user['uid']));

$form->addFieldForm($form->_group($form->_inputLabel(false, $user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false, $user['uid'], 'UID:')));
//$form->addFieldForm($form->_group($form->_inputLabel(false, $amount . ' грн.' , 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));
