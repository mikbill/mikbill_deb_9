<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */


/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$order_id = startTransaction($LINK, $user, $amount, 'addons_privat24', 'order_date');

$dillerID = getUsersGroupID($LINK, $user['uid']);

if($dillerID != 0){
    $dilerOptions = readCustomFieldsDealerOptions($LINK, $dillerID, true);

    // Еcли включен у субпровайдера Privat24
    if(isset($dilerOptions['do_privat24_terminal']) AND $dilerOptions['do_privat24_terminal'] == '1' ){
        // Перезапишем опции
        foreach ($dilerOptions as $key => $value){
            $systemOptions[$key] = $value;
        }
    }
}


$merchant_id = $systemOptions[$systemName . '_merchantid'];

$curency =  $systemOptions[$systemName . '_ccy'];
$url_result = $systemOptions[$systemName . '_server_url'];
$url_server = $systemOptions[$systemName . '_return_url'];
$procent = $systemOptions[$systemName . '_procent'];

$action_url = "https://api.privatbank.ua/p24api/ishop";

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('Приват24');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('POST');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('amt', $amount));
$form->addFieldForm($form->_input('ccy', $curency));

$form->addFieldForm($form->_input('merchant', $merchant_id));
$form->addFieldForm($form->_input('order', $order_id));

$form->addFieldForm($form->_input('details', 'internet '.$user['uid']));
$form->addFieldForm($form->_input('ext_details', ''));
$form->addFieldForm($form->_input('pay_way', 'privat24'));

$form->addFieldForm($form->_input('return_url', $url_server));
$form->addFieldForm($form->_input('server_url', $url_result));

$form->addFieldForm($form->_group($form->_inputLabel(false,$user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$amount.' '.$curency, 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));
