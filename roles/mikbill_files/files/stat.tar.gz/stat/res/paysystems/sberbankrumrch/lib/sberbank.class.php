<?php

/**
 * Class for working with Sberbank.ru REST
 **/
class Sberbank
{
	// Payment mode (secure or sandbox)
	private $userName;
	private $password;
	private $returnUrl;
	private $merchant;
	private $failUrl;
	private $mode = true;

	public function __construct($merchant, $userName, $password, $returnUrl, $failUrl, $mode = true)
	{
		$this->userName = $userName;
		$this->password = $password;
		$this->merchant = $merchant;
		$this->returnUrl = $returnUrl;
		$this->failUrl = $failUrl;
		$this->mode = $mode;
	}

	/**
	 * Generate url
	 *
	 * @param string $method Payler API method
	 *
	 * @return string
	 * @link 12. Координаты подключения (см. guide)
	 */
	public function getUrl($method)
	{
		if($this->mode){
			return 'https://securepayments.sberbank.ru/payment/rest/' . $method;
		}else{
			return 'https://3dsec.sberbank.ru/payment/rest/' . $method;
		}

	}

	/**
	 *  Starts a payment session and returns its ID
	 *
	 * @param $order_id
	 * @param $uid
	 * @param $amount
	 * @param $decription
	 *
	 * @return bool
	 */
	public function getFormUrl($order_id, $uid, $amount, $decription)
	{
		$data = array(
			'orderNumber' => $order_id,
			'userName'    => $this->userName,
			'password'    => $this->password,
			'returnUrl'   => $this->returnUrl,
			'amount'      => $amount * 100,

			'failUrl'     => $this->failUrl,
			'clientId'    => $uid,
			'description' => $decription
		);

		$sessionData = $this->sendRequest($data, 'register.do');

		if (isset($sessionData['formUrl'])) {
			return $sessionData['formUrl'];
		}else{
			return false;
		}
	}

	/**
	 * Sends a request to the server
	 *
	 * @param array  $data   API method parameters
	 * @param string $method Payler API method
	 *
	 * @return bool|mixed
	 */
	private function sendRequest($data, $method)
	{
		$data = http_build_query($data, '', '&');
		$url = $this->getUrl($method);

		$options = array(
			CURLOPT_URL            => $url,
			CURLOPT_POST           => true,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_TIMEOUT        => 45,
			CURLOPT_VERBOSE        => false,
			CURLOPT_HTTPHEADER     => array(
				'Content-type: application/x-www-form-urlencoded',
				'Cache-Control: no-cache',
				'charset="utf-8"',
			),
			CURLOPT_POSTFIELDS     => $data,
			CURLOPT_SSL_VERIFYHOST => false,
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_SSLVERSION => 6
		);

		$ch = curl_init();
		curl_setopt_array($ch, $options);
		$json = curl_exec($ch);
		$result = json_decode($json, true);
		curl_close($ch);

		return $result;
	}
}