<?php
/*
Uniteller Dashboard
*/

$orderid = startTransaction($LINK, $user, $amount, 'addons_uniteller');
$shop_IDP = $systemOptions[$systemName . '_shop_IDP']; // идентификатор точки продажи
$password = $systemOptions[$systemName . '_password'];
$signature = getSignature($shop_IDP, $orderid, $amount, "", "", "", $user['uid'], "", "", "", $password);

if (!empty($systemOptions[$systemName . '_url_return_ok'])){
    $urlReturnOK =  $systemOptions[$systemName . '_url_return_ok'];
}else{
    $urlReturnOK = "http://example.com/pay/ok";
}

if (!empty($systemOptions[$systemName . '_url_return_no'])){
    $urlReturnNO =  $systemOptions[$systemName . '_url_return_no'];
}else{
    $urlReturnNO = "http://example.com/pay/no";
}

if(!(empty($systemOptions['uniteller_test']) and $systemOptions['uniteller_test'] == 0)) {
    $actionUrl = 'https://test.wpay.uniteller.ru/pay/';
}else{
    $actionUrl = 'https://wpay.uniteller.ru/pay/';
}

# Название ПС
$form->setLabelForm('Uniteller');

# Заполняем action URL для формы
$form->setUrlForm($actionUrl);

# POST form
$form->setMethodForm('POST');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('Shop_IDP', $shop_IDP));
$form->addFieldForm($form->_input('Order_IDP', $orderid));
$form->addFieldForm($form->_input('Subtotal_P', $amount));
$form->addFieldForm($form->_input('Customer_IDP', $user['uid']));
$form->addFieldForm($form->_input('Signature', $signature));
$form->addFieldForm($form->_input('URL_RETURN_OK', $urlReturnOK));
$form->addFieldForm($form->_input('URL_RETURN_NO', $urlReturnNO));

$form->addFieldForm($form->_group($form->_inputLabel(false,$user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$amount.' руб.', 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));



function getSignature( $Shop_IDP, $Order_ID, $Subtotal_P, $MeanType, $EMoneyType, $Lifetime, $Customer_IDP, $Card_IDP, $IData, $PT_Code, $password ) {
    $Signature = strtoupper(
        md5(
            md5($Shop_IDP) . "&" .
            md5($Order_ID) . "&" .
            md5($Subtotal_P) . "&" .
            md5($MeanType) . "&" .
            md5($EMoneyType) . "&" .
            md5($Lifetime) . "&" .
            md5($Customer_IDP) . "&" .
            md5($Card_IDP) . "&" .
            md5($IData) . "&" .
            md5($PT_Code) . "&" .
            md5($password)
        )
    );
    return $Signature;
}